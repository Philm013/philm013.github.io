/**
 * @file js/db.js
 * @description A promise-based wrapper for IndexedDB to handle all application persistence.
 * Manages storage for projects, commits, and file snapshots.
 */

/**
 * An object providing methods to interact with the IndexedDB database.
 */
export const DB = {
    db: null,

    /**
     * Initializes the IndexedDB database. Creates object stores if they don't exist.
     * @returns {Promise<void>} A promise that resolves when the database is successfully opened.
     */
    init() {
        return new Promise((resolve, reject) => {
            // Open the database. Version 2 includes the 'rules' store.
            const request = indexedDB.open('ArchieDB', 2);

            request.onerror = () => reject("Error opening IndexedDB");
            request.onsuccess = (e) => {
                this.db = e.target.result;
                resolve();
            };

            // This event is fired when the database version changes.
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains('projects')) {
                    db.createObjectStore('projects', { keyPath: 'name' });
                }
                if (!db.objectStoreNames.contains('commits')) {
                    const commitStore = db.createObjectStore('commits', { keyPath: 'id' });
                    // Create an index to easily query commits by project name.
                    commitStore.createIndex('by_project', 'projectName', { unique: false });
                }
                if (!db.objectStoreNames.contains('fileSnapshots')) {
                    const fileStore = db.createObjectStore('fileSnapshots', { keyPath: ['commitId', 'path'] });
                    // Create an index to query all file snapshots for a given commit.
                    fileStore.createIndex('by_commit', 'commitId', { unique: false });
                }
            };
        });
    },

    /**
     * A helper to convert IndexedDB requests into Promises.
     * @param {IDBRequest} request - The IndexedDB request to promisify.
     * @returns {Promise<any>} A promise that resolves with the request's result or rejects with its error.
     */
    promisifyRequest(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    /**
     * Gets a specific object store from the database within a transaction.
     * @param {string} name - The name of the object store.
     * @param {'readonly' | 'readwrite'} [mode='readonly'] - The transaction mode.
     * @returns {Promise<IDBObjectStore>} A promise that resolves with the object store.
     */
    async getStore(name, mode = 'readonly') {
        return this.db.transaction(name, mode).objectStore(name);
    },

    /**
     * Retrieves all projects from the database.
     * @returns {Promise<Array<Object>>} A promise that resolves with an array of project data objects.
     */
    async getProjects() {
        const store = await this.getStore('projects');
        return this.promisifyRequest(store.getAll());
    },

    /**
     * Saves or updates a project's metadata (name, history, rules).
     * @param {Object} projectData - The project data to save.
     * @returns {Promise<IDBValidKey>} A promise that resolves with the key of the saved item.
     */
    async saveProject(projectData) {
        const store = await this.getStore('projects', 'readwrite');
        return this.promisifyRequest(store.put(projectData));
    },

    /**
     * Deletes a project and all its associated data (commits, snapshots).
     * @param {string} projectName - The name of the project to delete.
     * @returns {Promise<void>} A promise that resolves when the deletion is complete.
     */
    async deleteProject(projectName) {
        // First, get all commits for the project to find their IDs.
        const commits = await this.getCommits(projectName);
        const commitIds = commits.map(c => c.id);

        // Delete all file snapshots associated with those commits.
        const snapshotStore = await this.getStore('fileSnapshots', 'readwrite');
        for (const commitId of commitIds) {
            const index = snapshotStore.index('by_commit');
            const snapshots = await this.promisifyRequest(index.getAll(commitId));
            for (const snapshot of snapshots) {
                // snapshots have a compound key: [commitId, path]
                await this.promisifyRequest(snapshotStore.delete([snapshot.commitId, snapshot.path]));
            }
        }

        // Delete all the commits themselves.
        const commitStore = await this.getStore('commits', 'readwrite');
        for (const commitId of commitIds) {
            await this.promisifyRequest(commitStore.delete(commitId));
        }

        // Finally, delete the project entry.
        const projectStore = await this.getStore('projects', 'readwrite');
        return this.promisifyRequest(projectStore.delete(projectName));
    },

    /**
     * Retrieves all commits for a given project.
     * @param {string} projectName - The name of the project.
     * @returns {Promise<Array<Object>>} A promise that resolves with an array of commit objects.
     */
    async getCommits(projectName) {
        const store = await this.getStore('commits');
        const index = store.index('by_project');
        return this.promisifyRequest(index.getAll(projectName));
    },

    /**
     * Saves a commit metadata object to the database.
     * @param {Object} commitData - The commit data to save.
     * @returns {Promise<IDBValidKey>} A promise that resolves with the key of the saved commit.
     */
    async saveCommit(commitData) {
        const store = await this.getStore('commits', 'readwrite');
        return this.promisifyRequest(store.put(commitData));
    },

    /**
     * Retrieves all file snapshots from the most recent commit of a project.
     * @param {string} projectName - The name of the project.
     * @returns {Promise<Object.<string, string>>} A promise that resolves with a VFS-compatible file object.
     */
    async getLatestFileSnapshots(projectName) {
        const commits = await this.getCommits(projectName);
        if (commits.length === 0) return {};

        // Find the latest commit by timestamp.
        const latestCommit = commits.sort((a, b) => b.timestamp - a.timestamp)[0];

        const store = await this.getStore('fileSnapshots');
        const index = store.index('by_commit');
        const snapshots = await this.promisifyRequest(index.getAll(latestCommit.id));

        // Convert the array of snapshots into a key-value object for the VFS.
        const files = {};
        snapshots.forEach(s => { files[s.path] = s.content; });
        return files;
    },

    /**
     * Saves an array of file snapshot objects to the database.
     * @param {Array<Object>} snapshots - An array of snapshot objects to save.
     * @returns {Promise<void>} A promise that resolves when all snapshots have been saved.
     */
    async saveFileSnapshots(snapshots) {
        const store = await this.getStore('fileSnapshots', 'readwrite');
        for (const snapshot of snapshots) {
            await this.promisifyRequest(store.put(snapshot));
        }
    }
};