/**
 * @file js/ui.js
 * @description Manages all DOM manipulation, UI rendering, and event listeners for the application.
 */

import { App, $, uncommittedChanges, setStagedImage, stagedImage, conversationHistory, setUncommittedChanges } from './state.js';
import { ICONS } from './constants.js';
import { commitChanges, restoreToLastCommit, saveProjectState, handleProjectImport, downloadProjectAsZip } from './project.js';
import { submitPrompt, autoModeLoop, reconstructAndCleanHistory } from './api.js';
import { DB } from './db.js';
import { setPendingGuidance } from './state.js';
import * as github from './github.js';

// --- Feature: Slash Commands & Image Handling ---

const COMMANDS = {
    screenshot: {
        desc: "Capture the live preview pane.",
        action: () => {
            capturePreview().catch(err => alert(err.message || "Failed to capture screenshot."));
        }
    },
    generate_pad: {
        desc: "Analyze the project and generate a Project Architecture Document.",
        action: generatePadForProject
    },
    tool: { desc: "Suggest a tool for the AI to use.", isPrefix: true },
    clean_history: { desc: "Reconstructs history to match the terminal log, removing bloat.", action: reconstructAndCleanHistory }
};

/**
 * Handles the paste event on the user input to catch images.
 * @param {ClipboardEvent} e - The paste event.
 */
function handleImagePaste(e) {
    const items = e.clipboardData.items;
    for (const item of items) {
        if (item.type.indexOf('image') !== -1) {
            e.preventDefault();
            const file = item.getAsFile();
            const reader = new FileReader();
            reader.onload = (event) => {
                stageImage(event.target.result, file.type);
            };
            reader.readAsDataURL(file);
            break;
        }
    }
}

async function handleFileImport(event) {
            const files = event.target.files;
            if (!files.length) return;
            const filePromises = Array.from(files).map(readFileAsPromise);
            const fileResults = await Promise.all(filePromises);
            fileResults.forEach(result => {
                stageChange(result.path, result.content);
                logToTerminal(`Staged import of file: ${result.path}`, 'system');
            });
            renderFileExplorer();
            updateChangesUI();
            event.target.value = '';
        }

/**
 * Displays a pasted/captured image in the staging area above the input.
 * @param {string} base64 - The base64 data URL of the image.
 * @param {string} mimeType - The MIME type of the image.
 */
function stageImage(base64, mimeType) {
    setStagedImage({ base64, mimeType });
    const container = $('#staged-image-container');
    container.innerHTML = `<img src="${base64}" alt="Staged image"><button id="staged-image-remove-btn">×</button>`;
    container.style.display = 'block';
    $('#staged-image-remove-btn').addEventListener('click', () => {
        setStagedImage(null);
        container.style.display = 'none';
        container.innerHTML = '';
    });
}

/**
 * Handles input in the user textarea to show/hide the slash command menu.
 */
function handleSlashCommand() {
    const input = $('#user-input');
    const menu = $('#slash-command-menu');
    const text = input.value;
    if (text.startsWith('/')) {
        const query = text.substring(1).toLowerCase();
        const filteredCommands = Object.keys(COMMANDS).filter(cmd => cmd.startsWith(query));
        if (filteredCommands.length > 0) {
            renderCommandMenu(filteredCommands.slice(0, 10));
            menu.style.display = 'block';
        } else {
            menu.style.display = 'none';
        }
    } else {
        menu.style.display = 'none';
    }
}

/**
 * Renders the slash command menu with filtered commands.
 * @param {Array<string>} commands - The list of command names to render.
 */
function renderCommandMenu(commands) {
    const menu = $('#slash-command-menu');
    menu.innerHTML = '';
    commands.forEach((cmd, index) => {
        const item = document.createElement('div');
        item.className = 'command-item';
        if (index === 0) item.classList.add('selected');
        item.dataset.command = cmd;
        item.innerHTML = `<span class="command-name">/${cmd}</span><span class="command-desc">${COMMANDS[cmd].desc}</span>`;
        item.addEventListener('click', () => selectCommand(cmd));
        menu.appendChild(item);
    });
}

/**
 * Executes or inserts a selected slash command.
 * @param {string} cmd - The command string to execute.
 */
function selectCommand(cmd) {
    const input = $('#user-input');
    const menu = $('#slash-command-menu');
    if (COMMANDS[cmd] && COMMANDS[cmd].action) {
        COMMANDS[cmd].action();
        input.value = '';
    }
    menu.style.display = 'none';
    input.focus();
}

/**
 * Handles keyboard navigation (Up, Down, Enter) for the slash command menu.
 * @param {KeyboardEvent} e - The keydown event.
 */
function handleCommandMenuKeydown(e) {
    const menu = $('#slash-command-menu');
    if (menu.style.display === 'none') return;
    const items = Array.from(menu.querySelectorAll('.command-item'));
    if (items.length === 0) return;
    let currentIndex = items.findIndex(item => item.classList.contains('selected'));
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        currentIndex = (currentIndex + 1) % items.length;
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        currentIndex = (currentIndex - 1 + items.length) % items.length;
    } else if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        if (currentIndex > -1) {
            selectCommand(items[currentIndex].dataset.command);
        }
        return;
    } else {
        return;
    }
    items.forEach((item, index) => {
        item.classList.toggle('selected', index === currentIndex);
    });
}

/**
 * Captures a screenshot of the active preview pane using html2canvas.
 */
 async function capturePreview() {
            const allFiles = Object.keys(App.vfs.files);
            let htmlPath = allFiles.find(p => p.toLowerCase() === 'index.html');
            if (!htmlPath) {
                htmlPath = allFiles.find(p => p.toLowerCase().endsWith('.html') || p.toLowerCase().endsWith('.htm'));
            }

            if (!htmlPath) {
                throw new Error("No HTML file found in the project to preview.");
            }

            let wasInitiallyHidden = false;
            if (!App.previewModeFiles.has(htmlPath)) {
                wasInitiallyHidden = true;
                App.previewModeFiles.add(htmlPath);
                if (!App.openFiles.has(htmlPath)) App.openFiles.add(htmlPath);
                setActiveFile(htmlPath);
            } else {
                setActiveFile(htmlPath);
            }

            await new Promise(resolve => setTimeout(resolve, 100)); 

            const pane = $(`.editor-pane.active[data-path="${htmlPath}"]`);
            const frame = pane ? pane.querySelector('iframe') : null;

            if (!frame) {
                if (wasInitiallyHidden) {
                    App.previewModeFiles.delete(htmlPath);
                    renderEditor();
                }
                throw new Error("Could not find the preview iframe after attempting to open it.");
            }
            if (!frame.contentWindow || !frame.contentWindow.document.body.innerHTML.trim()) {
                 if (wasInitiallyHidden) {
                    App.previewModeFiles.delete(htmlPath);
                    renderEditor();
                }
                throw new Error("Preview is empty, nothing to capture.");
            }

            try {
                logToTerminal("Capturing screenshot of preview...", "system");
                const canvas = await html2canvas(frame.contentWindow.document.body, { useCORS: true, allowTaint: true, logging: false });
                const imgData = canvas.toDataURL('image/jpeg', 0.9);
                stageImage(imgData, 'image/jpeg');
                logToTerminal("Screenshot captured and staged.", "system");
            } catch (err) {
                console.error("html2canvas error:", err);
                throw new Error("Error during screenshot generation.");
            } finally {
                if (wasInitiallyHidden) {
                    App.previewModeFiles.delete(htmlPath);
                    renderEditor();
                }
            }
        }

/**
 * Logs a change proposal from the AI to the terminal, including a diff view
 * and buttons for user approval or rejection.
 * @param {string} path - The path of the file being changed.
 * @param {string} explanation - The AI's explanation for the change.
 * @param {string} originalContent - The original content of the file.
 * @param {string} newContent - The proposed new content of the file.
 * @returns {Promise<{approved: boolean, feedback?: string}>} A promise that resolves with the user's decision.
 */
export function logChangeProposal(path, explanation, originalContent, newContent) {
    return new Promise(resolve => {
        const terminal = $('#terminal-output');
        const entry = document.createElement('div');
        entry.className = 'log-entry log-ai log-change-proposal';

        // Use Diff library to generate diff parts
        const diff = Diff.diffLines(originalContent, newContent);
        const tempDiv = document.createElement('div');
        diff.forEach(part => {
            const tag = part.added ? 'ins' : part.removed ? 'del' : 'span';
            const node = document.createElement(tag);
            node.textContent = part.value;
            tempDiv.appendChild(node);
        });

        const diffHtml = `<pre class="diff-view-inline">${tempDiv.innerHTML}</pre>`;

        entry.innerHTML = `
            <div class="log-prefix">[AI]</div>
            <div class="proposal-content">
                <p><strong>Change proposal for ${path}:</strong></p>
                <p>${explanation}</p>
                <details>
                    <summary>View Diff</summary>
                    ${diffHtml}
                </details>
                <div class="proposal-actions">
                    <button class="approve-btn">Approve</button>
                    <button class="reject-btn">Reject</button>
                    <button class="reject-feedback-btn">Reject with Feedback</button>
                </div>
            </div>
        `;
        terminal.appendChild(entry);
        terminal.scrollTop = terminal.scrollHeight;

        const approveBtn = entry.querySelector('.approve-btn');
        const rejectBtn = entry.querySelector('.reject-btn');
        const rejectFeedbackBtn = entry.querySelector('.reject-feedback-btn');

        const finishInteraction = (decision) => {
            // Disable all buttons after a choice is made to prevent multiple clicks
            entry.querySelectorAll('button').forEach(btn => btn.disabled = true);
            resolve(decision);
        };

        approveBtn.onclick = () => finishInteraction({ approved: true });
        rejectBtn.onclick = () => finishInteraction({ approved: false });
        rejectFeedbackBtn.onclick = () => {
            const feedback = prompt("Please provide feedback for the AI:", "");
            // If the user cancels the prompt, feedback is null. We should handle this.
            finishInteraction({ approved: false, feedback: feedback || 'User rejected the update.' });
        };
    });
}

/**
 * Initiates a revision of a PAD section with the AI.
 * @param {string} sectionTitle - The title of the section to revise.
 * @param {string} oldSectionContent - The current markdown content of the section.
 */
async function revisePadSection(sectionTitle, oldSectionContent) {
    const instructions = prompt(`Enter instructions to revise the "${sectionTitle}" section:`);
    if (!instructions || !instructions.trim()) return;

    logToTerminal(`Revising PAD section "${sectionTitle}" with AI...`, 'system');
    const revisionPrompt = `You are a planning assistant. Revise the following section of a Project Architecture Document based on the user's instructions. Your response should ONLY be the complete, new, updated markdown for this entire section, starting with the "### ${sectionTitle}" heading.

**Section to Revise:** "${sectionTitle}"
**User's Instructions:** "${instructions}"
**Current Content:**
\`\`\`markdown
${oldSectionContent}
\`\`\`
`;
    const result = await submitPrompt(revisionPrompt);
    if (result && result.finalText) {
        const fullPadContent = App.vfs.read('PROJECT_ARCHITECTURE.md');
        const updatedFullPadContent = fullPadContent.replace(oldSectionContent, result.finalText);
        stageChange('PROJECT_ARCHITECTURE.md', updatedFullPadContent);
        renderPadView();
        updateChangesUI();
        logToTerminal(`PAD section "${sectionTitle}" updated.`, 'system');
    } else {
        logToTerminal(`Failed to revise PAD section.`, 'error');
    }
}

/**
 * Generates a new Project Architecture Document by analyzing the current project files.
 */
async function generatePadForProject() {
    if (App.vfs.read('PROJECT_ARCHITECTURE.md') && !confirm("A PAD file already exists. Overwrite it based on the current project state?")) {
        return;
    }
    logToTerminal("Analyzing project to generate a new PAD...", 'system');
    let analysisPrompt = `Analyze the following project files and generate a complete Project Architecture Document (PAD) for "${App.currentProjectName}". Infer the project's objective, features, and technical details from the code. Your response must ONLY be the new markdown content for the PAD file.

**PROJECT FILES FOR ANALYSIS:**
File Tree:
${App.vfs.getTreeString()}
`;
    const filesToAnalyze = Object.keys(App.vfs.files).filter(p => (p.endsWith('.html') || p.endsWith('.js') || p.endsWith('.css')) && p !== 'PROJECT_ARCHITECTURE.md').slice(0, 5);
    for (const path of filesToAnalyze) {
        analysisPrompt += `\n### File: ${path}\n\`\`\`\n${App.vfs.read(path).substring(0, 2500)}\n\`\`\`\n`;
    }
    const result = await submitPrompt(analysisPrompt);
    if (result && result.finalText && result.finalText.includes('# PAD:')) {
        stageChange('PROJECT_ARCHITECTURE.md', result.finalText);
        renderAll();
        renderPadView();
        updateChangesUI();
        logToTerminal("PAD generated successfully and staged as a change.", 'system');
        switchRightPaneTab('pad');
    } else {
        logToTerminal("Failed to generate PAD. The AI did not return the expected format.", 'error');
    }
}

/**
 * Toggles the AI's autonomous operation mode.
 */
function toggleAutoMode() {
    const btn = $('#auto-mode-btn');
    App.isAutoMode = !App.isAutoMode;
    btn.classList.toggle('active', App.isAutoMode);

    if (App.isAutoMode) {
        if (!App.vfs.read('PROJECT_ARCHITECTURE.md')) {
            alert("Cannot start Auto Mode. Please create a Project Architecture Document (PAD) first.");
            App.isAutoMode = false;
            btn.classList.remove('active');
            return;
        }
        logToTerminal(`Auto Mode enabled.`, 'system');
        autoModeLoop();
    } else {
        logToTerminal("Auto Mode disabled by user.", 'system');
    }
}

/**
 * Stages a change to be committed.
 * @param {string} path - The path of the file being changed.
 * @param {string|null} newContent - The new content, or null for deletion.
 */
export function stageChange(path, newContent) {
    const oldContent = App.vfs.read(path);
    // Only add to uncommitted if it's not already there, to preserve original diff state
    if (!uncommittedChanges[path]) {
        uncommittedChanges[path] = { oldContent: oldContent ?? null, newContent };
    } else {
        uncommittedChanges[path].newContent = newContent;
    }
    App.vfs.applyChange(path, newContent);
}

// --- Core Rendering Functions ---

/**
 * Renders the entire UI by calling individual component render functions.
 * This is a convenience function to refresh the main parts of the interface.
 */
export function renderAll() {
    renderFileExplorer();
    renderEditor();
}

/**
 * Renders the file explorer tree based on the current state of the Virtual File System.
 */
export function renderFileExplorer() {
    const tree = App.vfs.getTree();
    const container = $('#file-tree');
    container.innerHTML = '';

    const createTreeHTML = (node, path = '') => {
        const ul = document.createElement('ul');
        if (path === '') ul.style.paddingLeft = '0';

        // Sort directories before files
        const sortedKeys = Object.keys(node).sort((a, b) => {
            const aIsFile = node[a] === 'file';
            const bIsFile = node[b] === 'file';
            if (aIsFile === bIsFile) return a.localeCompare(b);
            return aIsFile ? 1 : -1;
        });

        sortedKeys.forEach(key => {
            const currentPath = path ? `${path}/${key}` : key;
            const li = document.createElement('li');
            li.dataset.path = currentPath;

            const wrapper = document.createElement('div');
            wrapper.className = 'file-item-wrapper';
            wrapper.addEventListener('contextmenu', (e) => showContextMenu(e, currentPath));

            const icon = document.createElement('span');
            icon.className = 'icon';

            const name = document.createElement('span');
            name.textContent = key;

            wrapper.appendChild(icon);
            wrapper.appendChild(name);
            li.appendChild(wrapper);

            if (node[key] === 'file') {
                icon.innerHTML = ICONS.file;
                wrapper.addEventListener('click', (e) => {
                    e.stopPropagation();
                    openFileInEditor(currentPath);
                });
            } else {
                icon.innerHTML = ICONS.folder;
                const childrenUl = createTreeHTML(node[key], currentPath);
                li.appendChild(childrenUl);
            }
            if (currentPath === App.activeFile) {
                li.classList.add('active');
            }
            ul.appendChild(li);
        });
        return ul;
    };
    container.appendChild(createTreeHTML(tree));
}


/**
 * Selects a rule in the list and displays it in the editor.
 * @param {string} ruleName - The name of the rule to select.
 */
function selectRule(ruleName) {
    document.querySelectorAll('.rule-item').forEach(item => item.classList.remove('selected'));
    const item = $(`.rule-item[data-name="${ruleName}"]`);
    if (item) item.classList.add('selected');

    const editor = $('#rule-editor-container');
    editor.style.display = 'flex';
    editor.dataset.currentRule = ruleName;
    $('#rule-name-input').value = ruleName;
    $('#rule-content-input').value = App.rules[ruleName] || '';
}

/**
 * Saves the currently edited rule.
 */
async function saveRule() {
    const editor = $('#rule-editor-container');
    const originalName = editor.dataset.currentRule;
    const newName = $('#rule-name-input').value.trim();
    const content = $('#rule-content-input').value;

    if (!newName) {
        alert("Rule name cannot be empty.");
        return;
    }
    if (originalName && originalName !== newName) {
        delete App.rules[originalName];
    }
    App.rules[newName] = content;
    await saveProjectState();
    renderRulesUI();
    selectRule(newName);
    logToTerminal(`Rule "${newName}" saved.`, 'system');
}

/**
 * Deletes the currently selected rule.
 */
async function deleteRule() {
    const editor = $('#rule-editor-container');
    const ruleName = editor.dataset.currentRule;
    if (ruleName && confirm(`Are you sure you want to delete the rule "${ruleName}"?`)) {
        delete App.rules[ruleName];
        await saveProjectState();
        renderRulesUI();
        editor.style.display = 'none';
        logToTerminal(`Rule "${ruleName}" deleted.`, 'system');
    }
}

/**
 * Sets up the event listeners for the context menu.
 */
function setupContextMenu() {
    const menu = $('#context-menu');
    menu.addEventListener('click', (e) => {
        const action = e.target.dataset.action;
        const path = menu.dataset.path;
        if (!action || !path) return;

        const isFolder = App.vfs.files[path] === null;
        const basePath = isFolder ? path : path.substring(0, path.lastIndexOf('/') + 1);

        switch (action) {
            case 'new-file': {
                const fileName = prompt("Enter new file name:", "new-file.txt");
                if (fileName) stageChange(basePath + fileName, '');
                break;
            }
            case 'new-folder': {
                const folderName = prompt("Enter new folder name:", "new-folder");
                if (folderName) stageChange(basePath + folderName + '/', null);
                break;
            }
            case 'rename': {
                const newName = prompt(`Enter new name for "${path}":`, path);
                if (newName && newName !== path) {
                    const content = App.vfs.read(path);
                    stageChange(path, null);
                    stageChange(newName, content);
                    if (App.openFiles.has(path)) {
                        closeFile(path);
                        openFileInEditor(newName);
                    }
                }
                break;
            }
            case 'delete': {
                if (confirm(`Are you sure you want to delete "${path}"?`)) {
                    stageChange(path, null);
                    if (App.openFiles.has(path)) closeFile(path);
                }
                break;
            }
        }
        updateChangesUI();
        renderAll();
    });
}

/**
 * Handles the submission of the main user input form.
 * @param {Event} e - The form submission event.
 */
async function handleUserInput(e) {
    e.preventDefault();
    let userText = $('#user-input').value.trim();
    if ((!userText && !stagedImage) || App.isGenerating) return;

    const imageToSend = stagedImage;
    setStagedImage(null);
    $('#staged-image-container').style.display = 'none';
    $('#staged-image-container').innerHTML = '';

    $('#user-input').value = '';
    $('#user-input').style.height = 'auto';

    await submitPrompt(userText, imageToSend);
}
/**
 * Renders the editor tabs and panes for all open files.
 */
export function renderEditor() {
    const tabsContainer = $('#editor-tabs');
    const panesContainer = $('#editor-panes');
    tabsContainer.innerHTML = '';
    panesContainer.querySelectorAll('.editor-pane:not(#welcome-pane)').forEach(p => p.remove());

    $('#welcome-pane').style.display = App.openFiles.size === 0 ? 'block' : 'none';

    App.openFiles.forEach(path => {
        const tab = document.createElement('div');
        tab.className = 'editor-tab';
        tab.dataset.path = path;
        tab.textContent = path.split('/').pop();
        if (path === App.activeFile) tab.classList.add('active');

        const closeBtn = document.createElement('button');
        closeBtn.className = 'tab-close-btn';
        closeBtn.innerHTML = ICONS.close;
        closeBtn.addEventListener('click', e => { e.stopPropagation(); closeFile(path); });
        tab.appendChild(closeBtn);

        if (path.endsWith('.html') || path.endsWith('.md') || path.endsWith('.markdown')) {
            const previewBtn = document.createElement('button');
            previewBtn.className = 'tab-preview-btn';
            previewBtn.title = "Toggle Live Preview";
            previewBtn.innerHTML = ICONS.eye;
            if (App.previewModeFiles.has(path)) previewBtn.classList.add('active');
            previewBtn.addEventListener('click', e => { e.stopPropagation(); toggleLivePreview(path); });
            tab.appendChild(previewBtn);
        }

        tab.addEventListener('click', () => setActiveFile(path));
        tabsContainer.appendChild(tab);

        const pane = document.createElement('div');
        pane.className = 'editor-pane';
        pane.dataset.path = path;
        if (path === App.activeFile) pane.classList.add('active');

        if (App.previewModeFiles.has(path)) {
            if (path.endsWith('.html')) {
                const iframe = document.createElement('iframe');
                iframe.title = `Live Preview for ${path}`;
                iframe.sandbox = "allow-scripts allow-same-origin";
                pane.appendChild(iframe);
            } else if (path.endsWith('.md') || path.endsWith('.markdown')) {
                const previewDiv = document.createElement('div');
                previewDiv.className = 'markdown-preview';
                const mdContent = App.vfs.read(path) ?? '';
                previewDiv.innerHTML = App.markdownConverter.makeHtml(mdContent);
                pane.appendChild(previewDiv);
            }
        } else {
            const editor = document.createElement('textarea');
            editor.className = 'code-editor';
            editor.value = App.vfs.read(path) ?? '';
            editor.dataset.path = path;
            editor.addEventListener('input', handleEditorInput);
            pane.appendChild(editor);
        }
        panesContainer.appendChild(pane);
    });
    updateLivePreview();
}

/**
 * Renders the Project Architecture Document (PAD) view from the markdown file.
 */
export function renderPadView() {
    const container = $('#pad-interactive-view');
    container.innerHTML = '';
    const padContent = App.vfs.read('PROJECT_ARCHITECTURE.md');

    if (!padContent) {
        container.innerHTML = `<p style="color: var(--subtle-text-color); padding: 20px;">No Project Architecture Document found. Use the <code>/generate_pad</code> command to create one.</p>`;
        return;
    }

    // Split by H3 headings, keeping the heading in the result
    const sections = padContent.split(/(?=^###\s)/m);

    sections.forEach((sectionContent, index) => {
        if (!sectionContent.trim()) return;

        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'pad-section';

        const header = document.createElement('div');
        header.className = 'pad-section-header';

        const titleMatch = sectionContent.match(/^###\s*(.*)/);
        const title = titleMatch ? titleMatch[1].trim() : `Section ${index + 1}`;

        const h3 = document.createElement('h3');
        h3.textContent = title;

        const reviseBtn = document.createElement('button');
        reviseBtn.className = 'pad-revise-btn';
        reviseBtn.textContent = 'Revise with AI';
        reviseBtn.onclick = () => revisePadSection(title, sectionContent);

        header.appendChild(h3);
        header.appendChild(reviseBtn);

        const contentDiv = document.createElement('div');
        contentDiv.className = 'pad-section-content';
        // Render the content part of the section as markdown
        const contentMarkdown = titleMatch ? sectionContent.substring(titleMatch[0].length) : sectionContent;
        contentDiv.innerHTML = App.markdownConverter.makeHtml(contentMarkdown);

        sectionDiv.appendChild(header);
        sectionDiv.appendChild(contentDiv);
        container.appendChild(sectionDiv);
    });
}

/**
 * Renders the Rules management UI.
 */
export function renderRulesUI() {
    const list = $('#rules-list');
    list.innerHTML = '';
    const editor = $('#rule-editor-container');
    editor.style.display = 'none';

    Object.keys(App.rules).sort().forEach(ruleName => {
        const item = document.createElement('div');
        item.className = 'rule-item';
        item.textContent = ruleName;
        item.dataset.name = ruleName;
        item.addEventListener('click', () => selectRule(ruleName));
        list.appendChild(item);
    });
}

/**
 * Renders the entire terminal output from the conversation history.
 */
export function renderTerminalFromHistory() {
    const terminal = $('#terminal-output');
    terminal.innerHTML = '';
    // Slice(2) to skip the initial system prompt and AI's "ready" message.
    const historyToRender = (App.conversationHistory || []).slice(2);
    historyToRender.forEach(entry => {
        let role = entry.role === 'model' ? 'ai' : 'user';
        let textContent = '';
        let imageContent = null;
        let isConfirmationResponse = false;

        if (entry.parts) {
            entry.parts.forEach(part => {
                if (part.text) {
                    textContent += part.text;
                } else if (part.inlineData) {
                    imageContent = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                } else if (part.functionResponse && part.functionResponse.name === 'askUserForConfirmation') {
                    isConfirmationResponse = true;
                    textContent = `You responded: ${part.functionResponse.response.user_response}`;
                }
            });
        }

        if (textContent.trim() || imageContent) {
            if (isConfirmationResponse) {
                logToTerminal(textContent, 'user');
            } else {
                logToTerminal(textContent || (role === 'user' ? '(Image attached)' : ''), role, imageContent);
            }
        }
    });
}

/**
 * Renders the GitHub integration view based on connection state.
 */
export function renderGitHubView() {
    const connectedView = $('#github-connected-view');
    const disconnectedView = $('#github-disconnected-view');
    const repoInput = $('#github-repo-input');

    if (App.githubConnected) {
        $('#github-repo-display').textContent = App.githubRepo;
        $('#github-branch-display').textContent = App.githubBranch;
        connectedView.style.display = 'block';
        disconnectedView.style.display = 'none';
    } else {
        repoInput.value = App.githubRepo || '';
        connectedView.style.display = 'none';
        disconnectedView.style.display = 'block';
    }
}


// --- UI State & Interaction Handlers ---

/**
 * Handles user input in the code editor, staging changes.
 * @param {Event} e - The input event from the textarea.
 */
async function handleEditorInput(e) {
    const path = e.target.dataset.path;
    const newContent = e.target.value;
    // Get the original content from the last commit for diffing
    const baseFiles = await DB.getLatestFileSnapshots(App.currentProjectName);
    const oldContent = uncommittedChanges[path] ? uncommittedChanges[path].oldContent : (baseFiles[path] || '');

    uncommittedChanges[path] = { oldContent, newContent };
    App.vfs.applyChange(path, newContent);
    updateChangesUI();

    // Update live previews if active
    if (App.previewModeFiles.has(path)) {
        if (path.endsWith('.md') || path.endsWith('.markdown')) {
            const pane = $(`#editor-panes .editor-pane[data-path="${path}"]`);
            const previewDiv = pane ? pane.querySelector('.markdown-preview') : null;
            if (previewDiv) {
                previewDiv.innerHTML = App.markdownConverter.makeHtml(newContent);
            }
        } else {
            updateLivePreview(); // For HTML files
        }
    }
}

/**
 * Opens a file in the editor, creating a new tab and pane if necessary.
 * @param {string} path - The path of the file to open.
 */
export function openFileInEditor(path) {
    if (!App.openFiles.has(path)) {
        App.openFiles.add(path);
    }
    setActiveFile(path);
    if (App.isMobile()) {
        setMobileView('editor');
    }
}

/**
 * Sets the specified file as the active one in the editor.
 * @param {string} path - The path of the file to activate.
 */
function setActiveFile(path) {
    App.activeFile = path;
    renderFileExplorer();
    renderEditor();
}

/**
 * Closes an editor tab and its corresponding pane.
 * @param {string} path - The path of the file to close.
 */
export function closeFile(path) {
    App.openFiles.delete(path);
    App.previewModeFiles.delete(path);
    if (App.activeFile === path) {
        // Activate the next available tab, or none if it was the last one
        App.activeFile = App.openFiles.values().next().value || null;
    }
    renderEditor();
}

/**
 * Toggles the live preview mode for a file.
 * @param {string} path - The path of the file.
 */
function toggleLivePreview(path) {
    if (App.previewModeFiles.has(path)) {
        App.previewModeFiles.delete(path);
    } else {
        App.previewModeFiles.add(path);
    }
    renderEditor();
}

/**
 * Switches the visible tab in the right-hand pane (Terminal, PAD, etc.).
 * @param {string} tabName - The name of the tab to activate.
 */
export function switchRightPaneTab(tabName) {
    document.querySelectorAll('.right-pane-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tabName));
    document.querySelectorAll('.right-pane-view').forEach(v => v.classList.toggle('active', v.id === `${tabName}-view`));
}

/**
 * Sets the active view on mobile devices (Explorer, Editor, Terminal).
 * @param {'explorer' | 'editor' | 'terminal'} view - The view to display.
 */
export function setMobileView(view) {
    App.mobileView = view;
    const appContainer = $('#app-container');
    appContainer.className = `mobile-view-${view}`;

    document.querySelectorAll('.mobile-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.view === view);
    });
}

/**
 * Toggles the loading state of the UI, disabling/enabling input fields.
 * @param {boolean} isLoading - Whether to show the loading state.
 * @param {string} [promptText=""] - The text of the prompt to display.
 */
export function toggleLoading(isLoading, promptText = "") {
    App.isGenerating = isLoading;
    $('#send-btn').disabled = isLoading;
    $('#user-input').disabled = isLoading;
    $('#auto-mode-guidance-form').classList.toggle('visible', isLoading && App.isAutoMode);

    const terminal = $('#terminal-output');
    let indicator = $('#thinking-indicator');

    if (isLoading) {
        if (indicator) indicator.remove();
        if (promptText) $('#commit-message').value = promptText;

        indicator = document.createElement('div');
        indicator.id = 'thinking-indicator';
        indicator.className = 'log-entry log-thinking';
        indicator.textContent = 'Archie is thinking...';
        terminal.appendChild(indicator);
        terminal.scrollTop = terminal.scrollHeight;
    } else {
        if (indicator) indicator.remove();
    }
}

// --- Terminal & Logging ---

/**
 * Appends a new log entry to the terminal output.
 * @param {string} message - The message to log.
 * @param {'system' | 'user' | 'ai' | 'error'} [source='system'] - The source of the message.
 * @param {string|null} [imageBase64=null] - A base64 encoded image to display.
 * @returns {HTMLElement} The created log entry element.
 */
export function logToTerminal(message, source = 'system', imageBase64 = null) {
    const terminal = $('#terminal-output');
    const entry = document.createElement('div');
    entry.className = `log-entry log-${source}`;

    const prefix = document.createElement('span');
    prefix.className = 'log-prefix';
    prefix.textContent = `[${source.toUpperCase()}]`;

    const content = document.createElement('span');
    content.textContent = message;

    entry.appendChild(prefix);
    entry.appendChild(content);

    // Add "Save as Rule" button to user and AI messages
    if (source === 'user' || source === 'ai') {
        const controls = document.createElement('div');
        controls.className = 'log-entry-controls';
        const saveRuleBtn = document.createElement('button');
        saveRuleBtn.textContent = 'Save as Rule';
        saveRuleBtn.className = 'log-save-rule-btn';
        saveRuleBtn.onclick = () => {
            const ruleName = prompt("Enter a name for this new rule:", `Rule from ${source} message`);
            if (ruleName && ruleName.trim()) {
                App.rules[ruleName.trim()] = content.textContent;
                saveProjectState().then(() => {
                    renderRulesUI();
                    logToTerminal(`Saved message as rule: "${ruleName.trim()}"`, 'system');
                    switchRightPaneTab('rules');
                    selectRule(ruleName.trim());
                });
            }
        };
        controls.appendChild(saveRuleBtn);
        entry.appendChild(controls);
    }

    if (imageBase64) {
        const img = document.createElement('img');
        img.src = imageBase64;
        entry.appendChild(img);
    }

    terminal.appendChild(entry);
    terminal.scrollTop = terminal.scrollHeight;
    return entry;
}

/**
 * Appends a new log entry to the GitHub log output.
 * @param {string} message - The message to log.
 * @param {'info' | 'success' | 'error'} [type='info'] - The type of message.
 * @returns {HTMLElement} The created log entry element.
 */
export function logToGitHub(message, type = 'info') {
    const log = $('#github-log');
    const entry = document.createElement('div');
    entry.className = `github-log-entry github-log-${type}`;
    entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
    return entry;
}

/**
 * Logs a summary of tool calls made by the AI.
 * @param {string} reasoning - The AI's reasoning for the calls.
 * @param {Array<Object>} calls - The array of function calls.
 * @param {Array<Object>} responses - The array of responses from the tool handlers.
 */
export function logToolCallSummary(reasoning, calls, responses) {
    const terminal = $('#terminal-output');
    const entry = document.createElement('div');
    entry.className = 'log-entry log-tool-summary';

    let summaryText = `AI is executing ${calls.length} tool call(s)...`;
    if (calls.length === 1) {
        const call = calls[0];
        summaryText = `AI is calling \`${call.name}\` on \`${call.args.path || call.args.oldPath || ''}\``;
    }

    let detailsHtml = `<div class="tool-details">`;
    if (reasoning) {
        detailsHtml += `<div class="tool-reasoning">${reasoning.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</div>`;
    }

    calls.forEach((call, index) => {
        const response = responses[index].functionResponse.response;
        const statusClass = response.success ? 'success' : 'failure';
        const statusIcon = response.success ? '✅' : '❌';
        detailsHtml += `
            <div class="tool-call-item">
                <strong class="${statusClass}">${statusIcon} ${call.name}</strong>
                <pre>Args: ${JSON.stringify(call.args, null, 2)}</pre>
                <pre>Result: ${JSON.stringify(response, null, 2)}</pre>
            </div>
        `;
    });
    detailsHtml += `</div>`;

    entry.innerHTML = `
        <details>
            <summary>${summaryText}</summary>
            ${detailsHtml}
        </details>
    `;

    terminal.appendChild(entry);
    terminal.scrollTop = terminal.scrollHeight;
}

// --- Versioning & Changes UI ---

/**
 * Updates the "History" tab UI to show uncommitted changes or the commit log.
 */
export function updateChangesUI() {
    const changeCount = Object.keys(uncommittedChanges).length;
    const badge = $('#history-tab-badge');
    const historyView = $('#history-view');

    badge.style.display = changeCount > 0 ? 'block' : 'none';
    badge.textContent = changeCount;

    historyView.classList.toggle('show-changes', changeCount > 0);
    historyView.classList.toggle('show-history-log', changeCount === 0);

    if (changeCount > 0) {
        const changesList = $('#changes-list');
        changesList.innerHTML = '<h4>Uncommitted Changes</h4>';
        Object.keys(uncommittedChanges).forEach(path => {
            const item = document.createElement('div');
            item.className = 'change-item';
            item.textContent = path;
            item.onclick = () => displayDiff(path);
            changesList.appendChild(item);
        });
        const firstChange = changesList.querySelector('.change-item');
        if (firstChange) {
            firstChange.click();
        } else {
            $('#diff-view').innerHTML = '';
        }
    } else {
        loadAndDisplayHistory();
    }
}

/**
 * Displays a diff for a selected uncommitted file.
 * @param {string} path - The path of the file to diff.
 */
function displayDiff(path) {
    const diffView = $('#diff-view');
    const change = uncommittedChanges[path];
    if (!change) {
        diffView.innerHTML = '';
        return;
    }
    const oldStr = change.oldContent || '';
    const newStr = change.newContent ?? '';

    const diff = Diff.diffLines(oldStr, newStr);
    const fragment = document.createDocumentFragment();

    diff.forEach(part => {
        const tag = part.added ? 'ins' : part.removed ? 'del' : 'span';
        const node = document.createElement(tag);
        node.textContent = part.value;
        fragment.appendChild(node);
    });

    diffView.innerHTML = '';
    diffView.appendChild(fragment);

    document.querySelectorAll('.change-item').forEach(el => el.classList.toggle('selected', el.textContent === path));
}

/**
 * Loads and displays the project's commit history.
 */
async function loadAndDisplayHistory() {
    const historyLog = $('#history-log');
    historyLog.innerHTML = '<h4>Commit History</h4>';
    if (!App.currentProjectName) return;
    const commits = (await DB.getCommits(App.currentProjectName)).sort((a, b) => b.timestamp - a.timestamp);

    if (commits.length === 0) {
        historyLog.innerHTML += '<p style="padding: 10px; color: var(--subtle-text-color);">No commits yet.</p>';
        return;
    }

    commits.forEach(commit => {
        const item = document.createElement('div');
        item.className = 'history-item';
        item.innerHTML = `
            <p class="commit-msg">${commit.message}</p>
            <p class="commit-date">${new Date(commit.timestamp).toLocaleString()}</p>
        `;
        historyLog.appendChild(item);
    });
}

// --- Live Preview ---

/**
 * Updates all active live previews. This is a complex function that handles
 * resolving relative paths for CSS, JS, and images into data URLs.
 */
function updateLivePreview() {
    const getMimeType = (path) => {
        if (path.endsWith('.css')) return 'text/css';
        if (path.endsWith('.js')) return 'application/javascript';
        if (path.endsWith('.svg')) return 'image/svg+xml';
        if (path.endsWith('.png')) return 'image/png';
        if (path.endsWith('.jpg') || path.endsWith('.jpeg')) return 'image/jpeg';
        if (path.endsWith('.gif')) return 'image/gif';
        if (path.endsWith('.webp')) return 'image/webp';
        if (path.endsWith('.woff')) return 'font/woff';
        if (path.endsWith('.woff2')) return 'font/woff2';
        return 'text/plain';
    };

    const toDataURL = (content, mimeType) => {
        if (content.startsWith('data:')) return content;
        if (mimeType === 'image/svg+xml') {
            const encoded = encodeURIComponent(content).replace(/'/g, '%27').replace(/"/g, '%22').replace(/</g, '%3C').replace(/>/g, '%3E').replace(/#/g, '%23').replace(/&/g, '%26');
            return `data:image/svg+xml,${encoded}`;
        }
        const base64 = btoa(unescape(encodeURIComponent(content)));
        return `data:${mimeType};base64,${base64}`;
    };

    App.previewModeFiles.forEach(htmlPath => {
        if (!htmlPath.endsWith('.html')) return;

        const pane = $(`#editor-panes .editor-pane[data-path="${htmlPath}"]`);
        const frame = pane ? pane.querySelector('iframe') : null;
        if (!frame) return;

        const htmlContent = App.vfs.read(htmlPath);
        if (htmlContent === undefined) {
            frame.srcdoc = `<html><body>File not found: ${htmlPath}</body></html>`;
            return;
        }

        const basePath = htmlPath.includes('/') ? htmlPath.substring(0, htmlPath.lastIndexOf('/') + 1) : '';
        const resolvePath = (base, relative) => {
            if (relative.startsWith('/') || relative.startsWith('http') || relative.startsWith('data:')) return relative;
            const stack = base.split('/').filter(p => p);
            if (base.endsWith('/')) stack.pop();
            const parts = relative.split('/');
            for (const part of parts) {
                if (part === '.') continue;
                if (part === '..') { if (stack.length > 0) stack.pop(); }
                else { stack.push(part); }
            }
            return stack.join('/');
        };

        let processedContent = htmlContent.replace(/(href|src)=["'](.+?)["']/g, (match, attr, value) => {
            if (value.startsWith('data:') || value.startsWith('http')) return match;
            const absolutePath = resolvePath(basePath, value);
            const fileContent = App.vfs.read(absolutePath);
            if (fileContent !== undefined) {
                let finalContent = fileContent;
                const mimeType = getMimeType(absolutePath);
                if (mimeType === 'text/css') {
                    const cssDir = absolutePath.includes('/') ? absolutePath.substring(0, absolutePath.lastIndexOf('/') + 1) : '';
                    finalContent = fileContent.replace(/url\((['"]?)(.*?)\1\)/g, (cssMatch, quote, cssPath) => {
                        if (cssPath.startsWith('data:') || cssPath.startsWith('http')) return cssMatch;
                        const assetPath = resolvePath(cssDir, cssPath);
                        const assetContent = App.vfs.read(assetPath);
                        return assetContent ? `url(${toDataURL(assetContent, getMimeType(assetPath))})` : cssMatch;
                    });
                }
                return `${attr}="${toDataURL(finalContent, mimeType)}"`;
            }
            return match;
        });
        frame.srcdoc = processedContent;
    });
}

// --- Context Menu & Modals ---

/**
 * Shows the right-click context menu for a file or folder.
 * @param {MouseEvent} e - The contextmenu event.
 * @param {string} path - The path of the item that was clicked.
 */
function showContextMenu(e, path) {
    e.preventDefault();
    e.stopPropagation();
    const menu = $('#context-menu');
    menu.dataset.path = path; // Store path on the menu itself
    menu.style.display = 'block';
    menu.style.left = `${e.clientX}px`;
    menu.style.top = `${e.clientY}px`;
}

/**
 * Shows the project manager modal, listing all saved projects.
 */
export async function showProjectManager() {
    const modal = $('#project-manager-modal');
    const list = $('#project-list');
    list.innerHTML = '';
    const projects = await DB.getProjects();
    projects.forEach(proj => {
        const li = document.createElement('li');
        li.textContent = proj.name;
        li.dataset.name = proj.name;
        li.addEventListener('click', () => {
            list.querySelectorAll('li').forEach(i => i.classList.remove('selected'));
            li.classList.add('selected');
        });
        list.appendChild(li);
    });
    modal.style.display = 'flex';
}

// --- Setup Functions ---

/**
 * Attaches all primary event listeners to UI elements.
 */
export function setupEventListeners() {
    // Main input form
    $('#input-form').addEventListener('submit', handleUserInput);
    $('#user-input').addEventListener('paste', handleImagePaste);
    $('#user-input').addEventListener('input', handleSlashCommand);
    $('#user-input').addEventListener('keydown', handleCommandMenuKeydown);

    // Auto-mode guidance form
    $('#auto-mode-guidance-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const guidanceInput = $('#guidance-input');
        const guidanceText = guidanceInput.value.trim();
        if (guidanceText) {
            setPendingGuidance(guidanceText);
            logToTerminal(`Guidance queued for next step: "${guidanceText}"`, 'user');
            guidanceInput.value = '';
        }
    });

    // Header controls
    $('#auto-mode-btn').addEventListener('click', toggleAutoMode);
    $('#model-selector').addEventListener('change', (e) => {
        App.selectedModel = e.target.value;
        logToTerminal(`Model switched to: ${e.target.options[e.target.selectedIndex].text}`, 'system');
    });

    // Explorer footer buttons
    $('#projects-btn').addEventListener('click', showProjectManager);
    $('#import-files-btn').addEventListener('click', () => $('#import-files-input').click());
    $('#download-zip-btn').addEventListener('click', downloadProjectAsZip);
    $('#import-files-input').addEventListener('change', handleFileImport);

    // Right pane tabs
    document.querySelectorAll('.right-pane-tab').forEach(tab => tab.addEventListener('click', e => {
        switchRightPaneTab(e.currentTarget.dataset.tab);
    }));

    // Terminal controls
    $('#clear-terminal-btn').addEventListener('click', () => {
        $('#terminal-output').innerHTML = '';
    });

    // History/Changes controls
    $('#commit-btn').addEventListener('click', commitChanges);
    $('#restore-changes-btn').addEventListener('click', restoreToLastCommit);

    // Rules controls
    $('#add-rule-btn').addEventListener('click', () => {
        const newRuleName = `New-Rule-${Date.now()}`;
        App.rules[newRuleName] = "";
        renderRulesUI();
        selectRule(newRuleName);
    });
    $('#save-rule-btn').addEventListener('click', saveRule);
    $('#delete-rule-btn').addEventListener('click', deleteRule);
    
    // GitHub controls
    $('#save-pat-btn').addEventListener('click', github.saveToken);
    $('#github-connect-btn').addEventListener('click', github.connect);
    $('#github-disconnect-btn').addEventListener('click', github.disconnect);
    $('#github-pull-btn').addEventListener('click', github.pull);
    $('#github-push-btn').addEventListener('click', () => {
        const message = prompt("Enter commit message for this push:");
        if(message) github.push(message);
    });


    // Mobile tabs
    document.querySelectorAll('.mobile-tab').forEach(tab => {
        tab.addEventListener('click', () => setMobileView(tab.dataset.view));
    });

    // Context menu
    document.addEventListener('click', () => $('#context-menu').style.display = 'none');
    setupContextMenu();

    // Resizers
    setupResizers();
}
/**
 * Sets up the draggable resizer bars for the UI layout.
 */
function setupResizers() {
    const explorerResizer = $('#explorer-resizer');
    const previewResizer = $('#preview-resizer');
    const ideLayout = $('#ide-layout');

    const onMouseMove = (callback) => (e) => {
        e.preventDefault();
        callback(e);
    };
    const onMouseUp = (mouseMoveHandler, mouseUpHandler) => () => {
        window.removeEventListener('mousemove', mouseMoveHandler);
        window.removeEventListener('mouseup', mouseUpHandler);
    };

    explorerResizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const mouseMoveHandler = onMouseMove((e) => {
            document.documentElement.style.setProperty('--explorer-width', `${e.clientX}px`);
        });
        const mouseUpHandler = onMouseUp(mouseMoveHandler, () => window.removeEventListener('mouseup', mouseUpHandler));
        window.addEventListener('mousemove', mouseMoveHandler);
        window.addEventListener('mouseup', mouseUpHandler);
    });

    previewResizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const mouseMoveHandler = onMouseMove((e) => {
            const totalWidth = ideLayout.offsetWidth;
            const newWidth = totalWidth - e.clientX;
            document.documentElement.style.setProperty('--right-pane-width', `${newWidth}px`);
        });
        const mouseUpHandler = onMouseUp(mouseMoveHandler, () => window.removeEventListener('mouseup', mouseUpHandler));
        window.addEventListener('mousemove', mouseMoveHandler);
        window.addEventListener('mouseup', mouseUpHandler);
    });
}