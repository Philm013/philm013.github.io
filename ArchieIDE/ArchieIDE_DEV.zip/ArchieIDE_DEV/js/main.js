/**
 * @file js/main.js
 * @description The main entry point for the Archie's IDE application.
 * This file initializes all modules, sets up the application state,
 * and orchestrates the startup sequence.
 */

// Import the GoogleGenAI class for API interaction.
import { GoogleGenAI } from "https://esm.run/@google/genai";

// Import modules with specific responsibilities.
import { DB } from './db.js';
import { App, $, setAi, setMarkdownConverter, setConversationHistory, setUncommittedChanges } from './state.js';
import { ICONS, LAST_SESSION_KEY } from './constants.js';
import { loadProject, startNewProject, handleProjectImport, migrateFromLocalStorage } from './project.js';
import { setupEventListeners, showProjectManager, setMobileView } from './ui.js';

/**
 * The main initialization function for the application.
 * This function is called once the DOM is fully loaded.
 */
async function init() {
    // 1. Initialize the database.
    await DB.init();

    // 2. Initialize the markdown converter.
    setMarkdownConverter(new showdown.Converter({ tables: true, simplifiedAutoLink: true, strikethrough: true, tasklists: true }));

    // 3. Set up all UI event listeners.
    setupEventListeners();
    setupInitialIcons();

    // 4. Check for mobile view and set initial layout.
    if (App.isMobile()) {
        setMobileView('editor');
    }

    // 5. Begin the application startup flow by checking for the API key.
    // The rest of the startup logic is handled in the API key submission flow.
    $('#api-key-modal').style.display = 'flex';
    $('#api-key-form').addEventListener('submit', (e) => {
        e.preventDefault();
        handleApiKeySubmit();
    });
}

/**
 * Handles the submission of the Gemini API key.
 * Initializes the AI, migrates old data if necessary, and shows the project start modal.
 */
async function handleApiKeySubmit() {
    const apiKey = $('#api-key-input').value.trim();
    if (!apiKey) {
        alert("Please enter a valid API key.");
        return;
    }

    try {
        // Initialize the AI with the provided key.
        const genAI = new GoogleGenAI({ apiKey });
        setAi(genAI);

        // Hide the API key modal.
        $('#api-key-modal').style.display = 'none';

        // Perform one-time data migration from localStorage to IndexedDB if needed.
        await migrateFromLocalStorage();

        // Show the project start modal.
        $('#project-start-modal').style.display = 'flex';
        setupProjectStartModal();

    } catch (error) {
        alert("Failed to initialize AI. Please check your API Key or see the console for errors.");
        console.error("AI Initialization Error:", error);
        // Show the API key modal again if initialization fails.
        $('#api-key-modal').style.display = 'flex';
    }
}

/**
 * Sets up the buttons and logic for the project start modal.
 */
async function setupProjectStartModal() {
    // Restore last project button
    const lastProjectName = localStorage.getItem(LAST_SESSION_KEY);
    const restoreBtn = $('#restore-btn');
    if (lastProjectName) {
        restoreBtn.disabled = false;
        restoreBtn.textContent = `Restore "${lastProjectName}"`;
        restoreBtn.onclick = async () => {
            if (await loadProject(lastProjectName)) {
                $('#project-start-modal').style.display = 'none';
                $('#app-container').style.display = 'flex';
            } else {
                alert("Could not restore the last session. It may have been deleted.");
                localStorage.removeItem(LAST_SESSION_KEY);
                setupProjectStartModal(); // Refresh modal state
            }
        };
    } else {
        restoreBtn.disabled = true;
        restoreBtn.textContent = 'No Project to Restore';
    }

    // Load a project button
    const allProjects = await DB.getProjects();
    const loadProjectBtn = $('#load-project-start-btn');
    if (allProjects.length > 0) {
        loadProjectBtn.disabled = false;
        loadProjectBtn.onclick = () => {
            $('#project-start-modal').style.display = 'none';
            showProjectManager();
        };
    } else {
        loadProjectBtn.disabled = true;
        loadProjectBtn.textContent = 'No Projects to Load';
    }

    // Start a new project button
    $('#start-fresh-btn').onclick = () => {
        $('#start-options-view').style.display = 'none';
        $('#new-project-prompt').style.display = 'block';
    };
    $('#cancel-new-project-btn').onclick = () => {
        $('#start-options-view').style.display = 'block';
        $('#new-project-prompt').style.display = 'none';
    };
    $('#new-project-form').onsubmit = (e) => {
        e.preventDefault();
        const description = $('#new-project-input').value.trim();
        if (description) {
            startNewProject(description);
        }
    };

    // Import from files button
    $('#import-start-btn').onclick = () => $('#import-project-input').click();
    $('#import-project-input').onchange = handleProjectImport;

    // Setup project manager modal buttons
    setupProjectManagerModal();
}

/**
 * Sets up the event listeners for the project manager modal.
 */
function setupProjectManagerModal() {
    $('#close-pm-btn').onclick = () => {
        $('#project-manager-modal').style.display = 'none';
        // If no project is loaded, go back to the start modal.
        if (!App.currentProjectName) {
            $('#project-start-modal').style.display = 'flex';
        }
    };

    $('#load-project-btn').onclick = async () => {
        const selected = $('#project-list .selected');
        if (selected) {
            await loadProject(selected.dataset.name);
            $('#project-manager-modal').style.display = 'none';
            $('#app-container').style.display = 'flex';
        } else {
            alert("Please select a project to load.");
        }
    };

    $('#delete-project-btn').onclick = async () => {
        const selected = $('#project-list .selected');
        if (selected) {
            const name = selected.dataset.name;
            if (confirm(`Are you sure you want to permanently delete project "${name}"? This cannot be undone.`)) {
                await DB.deleteProject(name);
                if (App.currentProjectName === name) {
                    // If we deleted the current project, reset the view.
                    App.currentProjectName = null;
                    App.vfs.load({});
                    setConversationHistory([]);
                    setUncommittedChanges({});
                    // TODO: Reset UI to a clean state.
                }
                // Refresh the project manager list.
                showProjectManager();
            }
        } else {
            alert("Please select a project to delete.");
        }
    };

    $('#save-project-btn').onclick = async () => {
        const oldName = App.currentProjectName || "new-project";
        const newName = prompt("Enter a name to save a copy of the current project:", `${oldName}-copy`);
        if (newName && newName.trim()) {
            // This is a complex operation, so it should be in the project module.
            // For now, we'll just log it.
            console.log(`Saving a copy as: ${newName.trim()}`);
            alert("Save-as functionality is under development.");
        }
    };
}

/**
 * Sets the initial SVG content for all icons in the UI.
 */
function setupInitialIcons() {
    $('#auto-mode-btn').innerHTML = `<span class="icon">${ICONS.robot}</span> Auto Mode`;
    $('#projects-btn').innerHTML = `<span class="icon">${ICONS.project}</span>`;
    $('#import-files-btn').innerHTML = `<span class="icon">${ICONS.import}</span>`;
    $('#download-zip-btn').innerHTML = `<span class="icon">${ICONS.download}</span>`;
    $('.mobile-tab[data-view="explorer"] .icon').innerHTML = ICONS.mobileExplorer;
    $('.mobile-tab[data-view="editor"] .icon').innerHTML = ICONS.mobileEditor;
    $('.mobile-tab[data-view="terminal"] .icon').innerHTML = ICONS.mobileTerminal;
}

// --- Application Start ---
// Wait for the DOM to be fully loaded before running the init function.
document.addEventListener('DOMContentLoaded', init);