/**
 * @file js/api.js
 * @description Manages all communication with the Google Gemini API, including prompt submission,
 * tool-calling loop, history management, and error handling.
 */

import {
    App, conversationHistory, pushToConversationHistory, setConversationHistory,
    setLastApiCallTimestamp, setPendingGuidance
} from './state.js';
import { toolsConfig, MIN_API_CALL_INTERVAL_MS } from './constants.js';
import { functionHandlers } from './tools.js';
import { logToTerminal, logToolCallSummary, toggleLoading, renderAll, updateChangesUI, renderTerminalFromHistory } from './ui.js';

/**
 * Prunes large or unnecessary data from the conversation history before saving it to persistent storage.
 * This helps keep the IndexedDB database size manageable.
 * @param {Array<Object>} history - The conversation history to clean.
 * @returns {Array<Object>} The pruned history.
 */
function pruneHistoryForStorage(history) {
    if (!history) return [];
    const contextMarker = '== PROJECT CONTEXT ==';

    return history.map(entry => {
        const newEntry = JSON.parse(JSON.stringify(entry)); // Deep copy

        // Remove large content from AI tool calls in the model's turn
        if (newEntry.role === 'model' && newEntry.parts) {
            newEntry.parts.forEach(part => {
                if (part.functionCall) {
                    const call = part.functionCall;
                    if (call.name === 'createFile' && call.args.content) {
                        call.args.content = `(Content of ${call.args.path} was created, not stored in history)`;
                    }
                    if (call.name === 'updateFile' && call.args.changes) {
                        call.args.changes.forEach(c => c.newContent = `(New content for ${call.args.path} was applied, not stored in history)`);
                    }
                }
            });
        }

        // Remove image data and context from the user's turn
        if (newEntry.role === 'user' && newEntry.parts) {
            // Remove image data
            newEntry.parts = newEntry.parts.map(part => {
                if (part.inlineData) {
                    return { text: '(Image was provided, not stored in history)' };
                }
                return part;
            }).filter(Boolean);

            // Remove project context block
            const firstPart = newEntry.parts[0];
            if (firstPart && firstPart.text) {
                const contextIndex = firstPart.text.indexOf(contextMarker);
                if (contextIndex !== -1) {
                    firstPart.text = firstPart.text.substring(0, contextIndex).trim();
                }
            }
        }
        return newEntry;
    });
}


/**
 * Prunes non-essential data from history before sending to the API to save tokens.
 * Specifically, removes image data from previous turns.
 * @param {Array<Object>} history - The full conversation history.
 * @returns {Array<Object>} The history pruned for the API call.
 */
function pruneHistoryForApiCall(history) {
    const prunedHistory = JSON.parse(JSON.stringify(history)); // Deep copy
    const lastIndex = prunedHistory.length - 1;

    return prunedHistory.map((entry, index) => {
        // Remove image data from all user turns except the very last one
        if (entry.role === 'user' && index !== lastIndex) {
            entry.parts = entry.parts.filter(part => !part.inlineData);
        }
        // Condense large tool responses (like readFile) to save tokens
        if (entry.role === 'user' && Array.isArray(entry.parts)) {
            entry.parts.forEach(part => {
                if (part.functionResponse) {
                    const { name, response } = part.functionResponse;
                    if ((name === 'readFile' || name === 'readFileLines') && response.content) {
                        const lineCount = response.content.split('\n').length;
                        response.content = `(Content pruned: Read ${lineCount} lines successfully)`;
                    }
                }
            });
        }
        return entry;
    });
}

/**
 * Wraps an API call to enforce a minimum delay between calls, preventing rate-limit errors.
 * Also handles 429 "Resource Exhausted" errors with an automatic retry.
 * @param {Function} apiFunction - The function that makes the actual API call.
 * @returns {Promise<any>} The result from the API call.
 */
async function throttleApiCall(apiFunction) {
    let retries = 1;
    while (retries >= 0) {
        const now = Date.now();
        const timeSinceLastCall = now - App.lastApiCallTimestamp;

        if (timeSinceLastCall < MIN_API_CALL_INTERVAL_MS) {
            const delay = MIN_API_CALL_INTERVAL_MS - timeSinceLastCall;
            logToTerminal(`Rate limit protection: Waiting for ${Math.round(delay/1000)}s...`, 'system');
            await new Promise(resolve => setTimeout(resolve, delay));
        }

        setLastApiCallTimestamp(Date.now());

        try {
            const result = await apiFunction();
            return result; // Success
        } catch (error) {
            // Check for the specific 429 rate limit error
            if (error.message && error.message.includes('429')) {
                logToTerminal(`Hit 429 Rate Limit error. Checking for retry delay...`, 'error');
                const retryDelayMatch = error.message.match(/"retryDelay":\s*"(\d+)s"/);
                if (retryDelayMatch && retries > 0) {
                    const delaySeconds = parseInt(retryDelayMatch[1], 10);
                    const delayMs = (delaySeconds + 1) * 1000; // Add a 1s buffer
                    logToTerminal(`API suggests retrying in ${delaySeconds}s. Waiting...`, 'system');
                    await new Promise(resolve => setTimeout(resolve, delayMs));
                    retries--;
                    continue; // Retry the while loop
                }
            }
            // If not a 429, or no retry info, or retries exhausted, re-throw the error.
            throw error;
        }
    }
}


/**
 * The core function for interacting with the Gemini API. It manages the entire
 * conversation turn, including the tool-calling loop.
 * @param {string} prompt - The user's text prompt.
 * @param {Object|null} image - The staged image data, if any.
 * @returns {Promise<{projectIsComplete: boolean, finalText: string}>} An object indicating if the project is complete and the final text from the AI.
 */
async function callGemini(prompt, image = null) {
    let projectIsComplete = false;
    let result;

    const originalHistoryLength = conversationHistory.length;
    // Create a temporary, pruned copy of the history for this API call sequence
    const apiHistory = pruneHistoryForApiCall(conversationHistory);

    // Construct the context block to be appended to the user's prompt
    let contextBlock = `\n\n== PROJECT CONTEXT ==\n`;
    contextBlock += `Current Project Name: ${App.currentProjectName}\n`;
    contextBlock += `File tree:\n${App.vfs.getTreeString()}\n`;
    if (App.activeFile) {
        let activeFileContent = App.vfs.read(App.activeFile) || '';
        if (activeFileContent.length > 2000) {
            activeFileContent = activeFileContent.substring(0, 2000) + "\n... (file truncated, use readFile for full content)";
        }
        contextBlock += `\nCurrently active file is "${App.activeFile}". Its content is:\n---\n${activeFileContent}\n---`;
    } else {
        contextBlock += `\nNo file is currently active.`;
    }

    const userPartsWithContext = [{ text: prompt + contextBlock }];
    if (image) {
        userPartsWithContext.push({
            inlineData: { data: image.base64.split(',')[1], mimeType: image.mimeType }
        });
    }

    apiHistory.push({ role: 'user', parts: userPartsWithContext });

    try {
        const generate = () => ai.models.generateContent({ model: App.selectedModel, contents: apiHistory, config: { tools: toolsConfig } });
        result = await throttleApiCall(generate);

        // Main tool-calling loop
        while (true) {
            const functionCalls = result.functionCalls;
            if (!functionCalls || functionCalls.length === 0) {
                // No more function calls, AI has responded with text.
                const aiResponseText = result.text;
                if (aiResponseText) {
                    logToTerminal(aiResponseText, 'ai');
                }
                apiHistory.push(result.candidates[0].content);
                break; // Exit the loop
            }

            // Add the AI's function-calling request to the temporary history
            apiHistory.push(result.candidates[0].content);
            const functionResponses = [];
            const reasoning = result.text; // The AI's "thinking" before calling tools

            // Execute all function calls
            for (const call of functionCalls) {
                if (call.name === 'projectComplete') {
                    projectIsComplete = true;
                }
                const handler = functionHandlers[call.name];
                if (handler) {
                    const response = await handler(call.args);
                    functionResponses.push({ functionResponse: { name: call.name, response: response } });
                }
            }

            logToolCallSummary(reasoning, functionCalls, functionResponses);

            if (functionResponses.length === 0) {
                logToTerminal('AI tried to call a function that does not exist. Halting.', 'error');
                break;
            }

            // Add the tool results back into the history for the AI to process
            apiHistory.push({ role: 'user', parts: functionResponses });

            // Call the API again with the tool results
            const nextGenerate = () => ai.models.generateContent({ model: App.selectedModel, contents: apiHistory, config: { tools: toolsConfig } });
            result = await throttleApiCall(nextGenerate);
        }

        // After the loop, update the main conversation history
        const newMessages = apiHistory.slice(originalHistoryLength);
        const cleanedMessages = pruneHistoryForStorage(newMessages);
        pushToConversationHistory(...cleanedMessages);

    } catch (error) {
        console.error("Error during Gemini interaction:", error);
        logToTerminal(`An error occurred: ${error.message}. Check console for errors.`, 'error');
        if (App.isAutoMode) {
            logToTerminal("Disabling Auto Mode due to error.", "system");
            App.isAutoMode = false;
        }
        throw error; // Re-throw to be caught by submitPrompt
    }

    return { projectIsComplete, finalText: result.text || "" };
}

/**
 * A wrapper function to handle the entire process of submitting a prompt to the AI.
 * It manages UI loading states and orchestrates the call to the AI.
 * @param {string} promptText - The user's text prompt.
 * @param {Object|null} image - The staged image data.
 * @returns {Promise<Object|null>} The result from the callGemini function, or null on error.
 */
export async function submitPrompt(promptText, image = null) {
    if (App.isGenerating) return;

    toggleLoading(true, promptText);
    logToTerminal(promptText || '(Image attached)', 'user', image ? image.base64 : null);

    try {
        const result = await callGemini(promptText, image);
        renderAll();
        updateChangesUI();
        return result;
    } catch (error) {
        // Error is already logged in callGemini. This just prevents a crash.
        console.error("Error in submitPrompt, but it was handled.", error);
        return null; // Indicate failure
    } finally {
        toggleLoading(false); // Crucially, always turn off the loading indicator.
    }
}

/**
 * The main loop for the AI's autonomous "Auto Mode".
 * It repeatedly reads the PAD, finds the next pending task, and executes it.
 */
export async function autoModeLoop() {
    if (!App.isAutoMode) {
        logToTerminal("Auto Mode has been disabled. Halting loop.", "system");
        return;
    }

    logToTerminal("Auto Mode: Starting next cycle...", "system");

    let nextPrompt = "You are in Auto Mode. Read the `PROJECT_ARCHITECTURE.md` file, find the first task in the 'Implementation Plan' table with a 'PENDING' status, and execute it using your tools. After you succeed, your next step MUST be to update the PAD to mark the task as 'COMPLETED' and add an entry to the 'Execution Log'.";

    if (App.pendingGuidance) {
        logToTerminal(`Injecting user guidance into auto-mode: "${App.pendingGuidance}"`, 'system');
        nextPrompt = `The user has provided guidance: "${App.pendingGuidance}". Please prioritize this, then continue with the PAD-driven workflow.`;
        setPendingGuidance(null); // Clear guidance after using it
    }

    const result = await submitPrompt(nextPrompt);

    if (App.isAutoMode && result && !result.projectIsComplete) {
        // Check if there are still pending tasks before looping
        const padContent = App.vfs.read('PROJECT_ARCHITECTURE.md') || '';
        if (padContent.includes('| PENDING |')) {
            autoModeLoop(); // Continue the loop
        } else {
            logToTerminal("Auto Mode: All tasks in PAD are complete. Halting.", 'system');
            App.isAutoMode = false;
        }
    } else {
        if (result && result.projectIsComplete) {
            logToTerminal("Auto Mode: Project marked as complete by AI. Halting.", 'system');
        }
        App.isAutoMode = false;
        // The UI for the button state will be updated in toggleAutoMode or the error handler.
    }
}


/**
 * Reconstructs the conversation history based on the visible terminal log.
 * This is a utility to clean up bloated history that might result from complex,
 * multi-step tool calls that are not essential for future context.
 */
export async function reconstructAndCleanHistory() {
    if (conversationHistory.length < 2) {
        logToTerminal("History is too short to clean.", 'system');
        return;
    }

    logToTerminal("Reconstructing history to match chat log...", 'system');
    const originalHistory = [...conversationHistory];
    const reconstructedHistory = [originalHistory[0], originalHistory[1]]; // Keep system prompt + initial AI response

    for (let i = 2; i < originalHistory.length; i++) {
        const entry = originalHistory[i];
        const newParts = [];

        // For user turns, just keep the text part (and a placeholder for images).
        if (entry.role === 'user') {
            const textPart = entry.parts.find(p => p.text);
            const imagePart = entry.parts.find(p => p.inlineData || (p.text && p.text.includes('(Image was provided')));
            if (textPart) newParts.push(textPart);
            if (imagePart && !textPart) {
                newParts.push({ text: '(Image was provided, not stored in history)' });
            }
        // For model turns, just keep the final text response, ignoring tool calls.
        } else if (entry.role === 'model') {
            const textPart = entry.parts.find(p => p.text);
            if (textPart && textPart.text.trim()) {
                newParts.push(textPart);
            }
        }

        if (newParts.length > 0) {
            reconstructedHistory.push({ role: entry.role, parts: newParts });
        }
    }

    const cleaned = pruneHistoryForStorage(reconstructedHistory);
    setConversationHistory(cleaned);
    renderTerminalFromHistory();
    logToTerminal("History reconstruction complete. Bloat has been removed and the clean history has been saved.", 'system');
}