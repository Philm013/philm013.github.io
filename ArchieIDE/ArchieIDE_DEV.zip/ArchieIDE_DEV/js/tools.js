/**
 * @file js/tools.js
 * @description Defines the handlers for all function-calling tools available to the Gemini AI.
 * Each function corresponds to a tool defined in the `toolsConfig` constant.
 */

import { App, uncommittedChanges, $ } from './state.js';
import { updateChangesUI, renderAll, stageChange, renderPadView, logToTerminal, setMobileView, switchRightPaneTab, logChangeProposal } from './ui.js';

/**
 * Parses a code string to find symbols like functions, classes, and IDs.
 * This is a helper function for the `get_code_symbols_outline` tool.
 * @param {string} content - The code content to parse.
 * @param {string} path - The path of the file, used to determine the language.
 * @returns {Array<{name: string, type: string, line: number}>} An array of found symbols.
 */
function parseCodeForSymbols(content, path) {
    const symbolRegexPatterns = {
        javascript: [
            { type: 'function', regex: /^(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\(/gm },
            { type: 'function', regex: /^(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*(?:async\s*)?\(/gm },
            { type: 'class', regex: /^class\s+([a-zA-Z0-9_$]+)/gm },
        ],
        css: [
            { type: 'class', regex: /^\.([a-zA-Z0-9_-]+)/gm },
            { type: 'id', regex: /^#([a-zA-Z0-9_-]+)/gm },
        ],
        html: [
            { type: 'id', regex: /id="([^"]+)"/g },
        ]
    };

    const extension = path.split('.').pop();
    let lang;
    if (['js', 'mjs', 'cjs'].includes(extension)) lang = 'javascript';
    else if (extension === 'css') lang = 'css';
    else if (['html', 'htm'].includes(extension)) lang = 'html';
    else return [];

    const patterns = symbolRegexPatterns[lang];
    if (!patterns) return [];

    const symbols = [];
    const lines = content.split('\n');

    lines.forEach((line, index) => {
        patterns.forEach(patternInfo => {
            // Use a new RegExp object for each iteration to reset the `lastIndex` property for global regexes.
            const regex = new RegExp(patternInfo.regex);
            let match;
            while ((match = regex.exec(line)) !== null) {
                symbols.push({
                    name: match[1],
                    type: patternInfo.type,
                    line: index + 1
                });
            }
        });
    });
    return symbols;
}

/**
 * A collection of handler functions for the AI's tools.
 * The keys of this object must match the `name` of the functions defined in `toolsConfig`.
 * @type {Object.<string, Function>}
 */
export const functionHandlers = {
    /**
     * Creates a new file in the virtual file system.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path for the new file.
     * @param {string} [args.content=''] - The initial content of the file.
     * @returns {{success: boolean, message: string}} The result of the operation.
     */
    createFile: (args) => {
        stageChange(args.path, args.content || '');
        return { success: true, message: `File ${args.path} staged for creation.` };
    },

    /**
     * Applies a series of changes to an existing file. This is the primary method
     * for code modification. It presents a diff to the user for approval.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path of the file to update.
     * @param {string} args.explanation - A user-facing summary of the changes.
     * @param {Array<{startLine: number, endLine: number, newContent: string}>} args.changes - The specific changes to apply.
     * @returns {Promise<{success: boolean, message?: string, error?: string, user_response?: string}>} The result of the operation.
     */
    updateFile: (args) => {
        return new Promise(async (resolve) => {
            const { path, explanation, changes } = args;
            const originalFullContent = App.vfs.read(path);

            if (typeof originalFullContent !== 'string') {
                return resolve({ success: false, error: `File not found at path: ${path}. You must read a file before trying to update it.` });
            }

            if (!changes || changes.length === 0) {
                return resolve({ success: false, error: "The 'changes' array cannot be empty." });
            }

            let lines = originalFullContent.split('\n');

            // Validate line numbers before making any changes.
            for (const change of changes) {
                if (change.startLine < 1 || change.endLine < change.startLine || change.endLine > lines.length) {
                    return resolve({ success: false, error: `Invalid line numbers provided for ${path}. Start: ${change.startLine}, End: ${change.endLine}. File has ${lines.length} lines. Please read the file again to get correct line numbers.` });
                }
            }

            // Sort changes in descending order of startLine to prevent modification conflicts.
            const sortedChanges = [...changes].sort((a, b) => b.startLine - a.startLine);

            sortedChanges.forEach(change => {
                const startIdx = change.startLine - 1;
                const endIdx = change.endLine - 1;
                const numLinesToRemove = endIdx - startIdx + 1;
                lines.splice(startIdx, numLinesToRemove, ...change.newContent.split('\n'));
            });

            const newFullContent = lines.join('\n');

            if (App.isMobile()) setMobileView('terminal');
            switchRightPaneTab('terminal');

            // The `logChangeProposal` function in ui.js will handle the user interaction.
            // It returns a promise that resolves based on the user's action.
            const userDecision = await logChangeProposal(path, explanation, originalFullContent, newFullContent);

            if (userDecision.approved) {
                stageChange(path, newFullContent);
                updateChangesUI();
                renderAll();
                if (path === 'PROJECT_ARCHITECTURE.md') {
                    renderPadView();
                }
                logToTerminal(`You approved the update for ${path}.`, 'user');
                resolve({ success: true, message: 'Update applied successfully.' });
            } else {
                const logMessage = userDecision.feedback
                    ? `You rejected the update for ${path} with feedback: "${userDecision.feedback}"`
                    : `You rejected the update for ${path}.`;
                logToTerminal(logMessage, 'user');
                resolve({ success: false, user_response: userDecision.feedback || 'User rejected the update.' });
            }
        });
    },
    
    /**
     * Deletes a file or folder from the virtual file system.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path to delete.
     * @returns {{success: boolean, message: string}} The result.
     */
    deleteFile: (args) => {
        if (typeof App.vfs.files[args.path] === 'undefined') {
            return { success: false, message: `Error: File or folder ${args.path} not found.` };
        }
        stageChange(args.path, null); // `null` content signifies deletion.
        return { success: true, message: `Path ${args.path} staged for deletion.` };
    },

    /**
     * Renames a file or folder in the VFS.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.oldPath - The original path.
     * @param {string} args.newPath - The new path.
     * @returns {{success: boolean, message: string}} The result.
     */
    renamePath: (args) => {
        const content = App.vfs.read(args.oldPath);
        stageChange(args.oldPath, null);
        stageChange(args.newPath, content);
        return { success: true, message: `Path ${args.oldPath} staged for rename to ${args.newPath}.` };
    },

    /**
     * Reads the full content of a specified file.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path of the file to read.
     * @returns {{success: boolean, content?: string, error?: string}} The result.
     */
    readFile: (args) => {
        const content = App.vfs.read(args.path);
        if (content === undefined) {
            return { success: false, error: 'File not found.' };
        }
        return { success: true, content: content };
    },

    /**
     * Reads a specific range of lines from a file.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path of the file.
     * @param {number} args.startLine - The 1-indexed starting line.
     * @param {number} args.endLine - The 1-indexed ending line.
     * @returns {{success: boolean, content?: string, error?: string}} The result.
     */
    readFileLines: (args) => {
        const content = App.vfs.read(args.path);
        if (content === undefined) return { success: false, error: 'File not found.' };
        const lines = content.split('\n');
        const start = Math.max(0, args.startLine - 1);
        const end = Math.min(lines.length, args.endLine);
        if (start >= end) return { success: false, error: 'Invalid line range.' };
        return { success: true, content: lines.slice(start, end).join('\n') };
    },

    /**
     * Provides a structural outline of a file by listing its symbols, or gets the definition of a single symbol.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.path - The path of the file.
     * @param {string} [args.symbolName] - Optional. If provided, fetches the definition of this symbol.
     * @returns {{success: boolean, symbols?: Array, definition?: string, error?: string}} The result.
     */
    get_code_symbols_outline: (args) => {
        const { path, symbolName } = args;
        const content = App.vfs.read(path);
        if (content === undefined) return { success: false, error: 'File not found.' };

        if (symbolName) {
            const lines = content.split('\n');
            let definition = '';
            let inDefinition = false;
            let braceCount = 0;
            const symbolRegex = new RegExp(`\\b${symbolName}\\b`);

            for (const line of lines) {
                if (!inDefinition && line.match(symbolRegex)) {
                    inDefinition = true;
                }
                if (inDefinition) {
                    definition += line + '\n';
                    braceCount += (line.match(/{/g) || []).length;
                    braceCount -= (line.match(/}/g) || []).length;
                    // Heuristic to stop parsing once braces are balanced after finding the symbol.
                    if (braceCount === 0 && definition.length > 10) {
                        break;
                    }
                }
            }
            if (definition) {
                return { success: true, definition };
            } else {
                return { success: false, error: `Symbol '${symbolName}' not found.` };
            }
        } else {
            const symbols = parseCodeForSymbols(content, path);
            return { success: true, symbols };
        }
    },

    /**
     * Searches for a text pattern or regex across all files in the project.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.query - The search string or regex pattern.
     * @param {boolean} [args.isRegex=false] - Whether the query is a regex.
     * @returns {{success: boolean, results: Array}} The search results.
     */
    searchProject: (args) => {
        const results = [];
        const regex = new RegExp(args.query, args.isRegex ? 'g' : 'gi');
        Object.keys(App.vfs.files).forEach(path => {
            const content = App.vfs.read(path);
            if (content === null) return; // Skip directories
            const lines = content.split('\n');
            lines.forEach((line, index) => {
                if (line.match(regex)) {
                    results.push({ path, line: index + 1, content: line.trim() });
                }
            });
        });
        return { success: true, results };
    },

    /**
     * Fetches project-specific rules and guidelines.
     * @param {object} args - The arguments for the tool.
     * @param {string} [args.ruleName] - The name of the rule to fetch. If omitted, lists all rule names.
     * @returns {{success: boolean, content?: string, ruleNames?: Array, error?: string}} The result.
     */
    fetchProjectRules: (args) => {
        if (args.ruleName) {
            const content = App.rules[args.ruleName];
            if (content) {
                return { success: true, name: args.ruleName, content: content };
            } else {
                return { success: false, error: `Rule '${args.ruleName}' not found.` };
            }
        } else {
            const ruleNames = Object.keys(App.rules);
            return { success: true, ruleNames: ruleNames };
        }
    },

    /**
     * Asks the user a yes/no question to confirm a high-level plan or action.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.question - The question to ask the user.
     * @returns {Promise<{success: boolean, user_response: 'yes'|'no'}>} The user's response.
     */
    askUserForConfirmation: (args) => {
        if (App.isAutoMode) {
            logToTerminal(`Auto-confirming: ${args.question}`, 'ai');
            return { success: true, user_response: 'yes' };
        }
        return new Promise(resolve => {
            if (App.isMobile()) setMobileView('terminal');
            const entry = logToTerminal(`Q: ${args.question}`, 'ai');
            entry.classList.add('log-confirmation');

            const actionsDiv = document.createElement('div');
            actionsDiv.className = 'log-actions';

            const yesBtn = document.createElement('button');
            yesBtn.textContent = 'Yes';
            const noBtn = document.createElement('button');
            noBtn.textContent = 'No';

            const listener = (response) => {
                yesBtn.disabled = true;
                noBtn.disabled = true;
                logToTerminal(`You responded: ${response}`, 'user');
                resolve({ success: true, user_response: response });
            };

            yesBtn.onclick = () => listener('yes');
            noBtn.onclick = () => listener('no');

            actionsDiv.appendChild(yesBtn);
            actionsDiv.appendChild(noBtn);
            entry.appendChild(actionsDiv);
            switchRightPaneTab('terminal');
        });
    },

    /**
     * A tool for the AI to signal that it believes the user's request is complete.
     * @param {object} args - The arguments for the tool.
     * @param {string} args.message - A final message to the user.
     * @returns {{success: boolean, final_message: string}} The result.
     */
    projectComplete: (args) => {
        logToTerminal(`Project Complete: ${args.message}`, 'ai');
        return { success: true, final_message: args.message };
    }
};