import { Type } from "https://esm.run/@google/genai";

/**
 * @file js/constants.js
 * @description Defines and exports static constants used throughout the application.
 * This includes UI elements like icons, AI-related prompts and configurations,
 * and other fixed values.
 */

/**
 * A collection of SVG strings for icons used in the UI.
 * @type {Object.<string, string>}
 */
export const ICONS = {
    file: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM16 18H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>`,
    folder: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>`,
    close: `×`,
    mobileExplorer: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/></svg>`,
    mobileEditor: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M9.4 7.4L8 6l-6 6 6 6 1.4-1.4L3.8 12l5.6-4.6zm5.2 0L16 6l6 6-6 6-1.4-1.4L20.2 12l-5.6-4.6z"/></svg>`,
    mobileTerminal: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zM4 18V6h16v12H4zm2-7h4v2H6v-2zm5 0h6v2h-6v-2z"/></svg>`,
    project: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 6h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6 0h-4V4h4v2z"/></svg>`,
    import: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v4h3l-4 4-4-4h3V7z"/></svg>`,
    download: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>`,
    eye: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5c-5.22 0-9.87 3.32-11.83 8.5C2.13 13.18 6.78 16.5 12 16.5s9.87-3.32 11.83-8.5C21.87 7.32 17.22 4.5 12 4.5zm0 10c-2.48 0-4.5-2.02-4.5-4.5S9.52 5.5 12 5.5s4.5 2.02 4.5 4.5-2.02 4.5-4.5 4.5zM12 7.5c-1.38 0-2.5 1.12-2.5 2.5s1.12 2.5 2.5 2.5 2.5-1.12 2.5-2.5-1.12-2.5-2.5-2.5z"/></svg>`,
    robot: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a2 2 0 0 0-2 2v2H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-2V4a2 2 0 0 0-2-2zm-4 8a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm8 0a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm-4 4h-4v2h4v-2z"/></svg>`
};

/**
 * The default markdown template for a new Project Architecture Document (PAD).
 * @type {string}
 */
export const PAD_TEMPLATE = `# PAD: [ProjectHandle]
# Stack: HTML, JavaScript (ES6+), CSS

- **Version:** 1.0.0
- **LastUpdated:** {timestamp}
- **OverallStatus:** [PLANNING | CODING | REFINING | COMPLETED]

---

### 1. Core Directives & UI/UX Plan

<!-- LLM: This section defines the project's purpose and the user-facing features to be built. -->

**1.1. Project Objective:**
<!-- LLM: A single, concise, machine-parseable sentence describing the end goal. -->
> Create a static web application that allows a user to [primary_verb] and [secondary_verb] [primary_noun] using only client-side code.

**1.2. Feature Set (User Stories):**
<!-- LLM: Master list of user-facing features. Update 'status' as you implement the required files and logic. -->
| FeatureID | User Story                                         | Priority | Status      | ComponentIDs |
|-----------|----------------------------------------------------|----------|-------------|--------------|
| \`F-01\`    | As a user, I can see a list of items from a data source. | P0       | PENDING     | \`C-HTML\`, \`C-JS-RENDER\`, \`C-DATA\` |
| \`F-02\`    | As a user, I can filter the list of items by typing in a search box. | P1       | PENDING     | \`C-HTML\`, \`C-JS-INTERACT\` |
| \`F-03\`    | As a user, I can click an item to see more details. | P1       | PENDING     | \`C-JS-INTERACT\`, \`C-CSS\` |
| \`F-04\`    | As a user, the layout is responsive and usable on mobile screens. | P2       | PENDING     | \`C-CSS\`      |
| \`...\`     | ...                                                | ...      | PENDING     | \`...\`        |

---

### 2. Technical Blueprint & File Architecture

<!-- LLM: This section defines the file structure and the contracts between them. This is your primary implementation guide. -->

**2.1. File & Component Structure:**
<!-- LLM: A map of all files to be created and their purpose. -->
\`\`\`
/
|-- index.html      # C-HTML: The main entry point and structure of the application.
|-- /css
|   |-- style.css   # C-CSS: Main stylesheet for layout, typography, and colors.
|-- /js
|   |-- main.js     # C-JS-MAIN: Main script, initializes the app, event listeners.
|   |-- render.js   # C-JS-RENDER: Functions for rendering data to the DOM.
|   |-- events.js   # C-JS-INTERACT: Handlers for user interactions (clicks, input).
|-- /data
|   |-- data.json   # C-DATA: The static data source for the application.
|-- /assets
|   |-- ...         # Image files, icons, etc.
\`\`\`

**2.2. Data Structure (\`/data/data.json\`):**
<!-- LLM: Define the expected structure of your primary data file. -->
\`\`\`json
[
  {
    "id": "unique-id-1",
    "title": "Sample Title 1",
    "description": "A longer description of the item.",
    "category": "Category A",
    "imageUrl": "assets/image1.png",
    "attributes": {
      "key1": "value1",
      "key2": "value2"
    }
  },
  {
    "id": "unique-id-2",
    "title": "Sample Title 2",
    "description": "Another item description.",
    "category": "Category B",
    "imageUrl": "assets/image2.png",
    "attributes": {
      "key1": "value3",
      "key2": "value4"
    }
  }
]
\`\`\`

**2.3. JavaScript Module & Function Contracts:**
<!-- LLM: Define the key functions and their responsibilities. This is the contract between your JS files. -->
| File        | Function Name             | Inputs                     | Outputs/Effects                                 | Status  |
|-------------|---------------------------|----------------------------|-------------------------------------------------|---------|
| \`main.js\`   | \`init()\`                  | -                          | Calls \`fetchData\` and \`renderList\`. Attaches event listeners. | PENDING |
| \`main.js\`   | \`fetchData()\`             | \`(filePath)\`               | \`Promise<Array>\`: Returns parsed data from JSON file. | PENDING |
| \`render.js\` | \`renderList(items)\`       | \`(items: Array)\`           | \`void\`: Clears and populates the main list container in the DOM. | PENDING |
| \`render.js\` | \`createItemElement(item)\` | \`(item: Object)\`           | \`HTMLElement\`: Returns a single DOM element for an item. | PENDING |
| \`events.js\` | \`handleSearchInput(event)\`| \`(event: InputEvent)\`      | Filters the main item list based on search term. Calls \`renderList\`. | PENDING |
| \`events.js\` | \`handleItemClick(event)\`  | \`(event: MouseEvent)\`      | Finds the clicked item's data and displays its details. | PENDING |

**2.4. CSS Design System & Naming Convention:**
<!-- LLM: Define the visual guidelines and class structure. -->
- **Color Palette:**
  - \`--primary-color: #005f73;\`
  - \`--secondary-color: #0a9396;\`
  - \`--background-color: #e9d8a6;\`
  - \`--text-color: #333333;\`
  - \`--accent-color: #ee9b00;\`
- **Typography:**
  - \`font-family: 'Arial', sans-serif;\`
  - \`font-size-base: 16px;\`
  - \`font-size-h1: 2.5rem;\`
- **Naming Convention:** BEM (Block Element Modifier).
  - **Example:** \`.item-list__item--selected\`

---

### 3. Implementation Plan & Task Breakdown

<!-- LLM: Your step-by-step execution plan. Work through these tasks sequentially. -->

| TaskID  | FeatureID | Action                                               | Target File(s)          | Status  |
|---------|-----------|------------------------------------------------------|-------------------------|---------|
| \`T-01.01\` | \`F-01\`    | Create \`index.html\` with basic HTML5 boilerplate.     | \`index.html\`            | PENDING |
| \`T-01.02\` | \`F-01\`    | Add main layout containers to \`index.html\` (e.g., \`<header>\`, \`<main>\`, \`<footer>\`). | \`index.html\`            | PENDING |
| \`T-01.03\` | \`F-01\`    | Create and link \`style.css\` and \`main.js\` in \`index.html\`. | \`index.html\`            | PENDING |
| \`T-01.04\` | -         | Create \`data/data.json\` with initial mock data.      | \`data/data.json\`        | PENDING |
| \`T-01.05\` | -         | Define CSS variables and base styles in \`style.css\`. | \`css/style.css\`         | PENDING |
| \`T-02.01\` | \`F-01\`    | Implement \`fetchData()\` function in \`main.js\`.       | \`js/main.js\`            | PENDING |
| \`T-02.02\` | \`F-01\`    | Implement \`createItemElement()\` function in \`render.js\`. | \`js/render.js\`          | PENDING |
| \`T-02.03\` | \`F-01\`    | Implement \`renderList()\` function in \`render.js\`.    | \`js/render.js\`          | PENDING |
| \`T-02.04\` | \`F-01\`    | Implement \`init()\` in \`main.js\` to load and display initial data. | \`js/main.js\`            | PENDING |
| \`T-03.01\` | \`F-02\`    | Add a search \`<input>\` element to \`index.html\`.      | \`index.html\`            | PENDING |
| \`T-03.02\` | \`F-02\`    | Implement \`handleSearchInput()\` in \`events.js\`.      | \`js/events.js\`          | PENDING |
| \`T-03.03\` | \`F-02\`    | Attach \`handleSearchInput\` to the search input's \`keyup\` event in \`main.js\`. | \`js/main.js\`            | PENDING |
| \`T-04.01\` | \`F-04\`    | Add CSS Flexbox/Grid layouts for main containers.      | \`css/style.css\`         | PENDING |
| \`T-04.02\` | \`F-04\`    | Add CSS Media Queries for mobile screen sizes (\`@media (max-width: 600px)\`). | \`css/style.css\`         | PENDING |
| \`...\`   | \`...\`     | ...                                                  | \`...\`                   | PENDING |

---

### 4. Decision & Execution Log

<!-- LLM: Your write-only section. Log all significant actions and outcomes here. -->

**4.1. Decision Log:**
<!-- LLM: Record any clarifications or choices made during development. -->
| Timestamp | Decision/Clarification                                     | Rationale                                       |
|-----------|------------------------------------------------------------|-------------------------------------------------|
| \`{ts}\`    | Using ES6 Modules (\`import\`/\`export\`) for JS organization. | Improves code separation and reusability.       |
| \`{ts}\`    | Will use native \`fetch\` API.                               | No need for external libraries like Axios for this simple project. |
| \`{ts}\`    | State will be managed in a simple global object in \`main.js\`. | Sufficient for this scale; no complex state library needed. |
| \`...\`     | ...                                                        | ...                                             |

**4.2. Execution Log:**
<!-- LLM: Append an entry here after completing each task from the Task Breakdown (3). -->
| Timestamp | TaskID  | Action Taken & Result                                 | Files Modified                    |
|-----------|---------|-------------------------------------------------------|-----------------------------------|
| \`{ts}\`    | \`T-01.01\` | \`SUCCESS: Created index.html with boilerplate.\`       | \`index.html\`                      |
| \`{ts}\`    | \`T-01.02\` | \`SUCCESS: Added <header>, <main>, <footer> tags.\`     | \`index.html\`                      |
| \`...\`     | \`...\`   | ...                                                   | \`...\`                             |
`;

/**
 * The system prompt that instructs the AI on its role, capabilities, and rules.
 * @type {string}
 */
export const SYSTEM_PROMPT = `You are "Archie", a world-class AI developer agent. Your purpose is to collaborate with a user to build and modify web projects from scratch. You operate inside a special browser-based IDE and can only interact with the project files using the provided set of tools. Your goal is to translate the user's requests into functional code by intelligently using these tools.

**THE CARDINAL RULE: READ, PLAN, THEN WRITE.**
This is the most important rule. To modify a file, you must follow this sequence:
1.  **Read:** Use \`readFile\` to get the file's most up-to-date content and understand its structure and line numbers.
2.  **Plan:** In your reasoning, decide on all the changes you need to make.
3.  **Write:** Use the \`updateFile\` tool to execute all your planned changes in a single, batched operation.

Basing your changes on stale or assumed content will cause your actions to fail. The \`updateFile\` tool operates on line numbers, so you must read the file first to know which lines to target.

---

### Core Workflow: The Project Architecture Document (PAD)

Your entire operation is driven by the \`PROJECT_ARCHITECTURE.md\` file. This is your single source of truth for planning, execution, and tracking.

1.  **Planning Phase (User-driven):** The user will interact with you to define the project's goals and structure within the PAD. Your role is to act as an expert architect, translating their high-level requests into detailed, actionable plans within the PAD's tables.
2.  **Execution Phase (Auto Mode):** When Auto Mode is activated, you will execute the plan laid out in the PAD. You must follow this strict, unbreakable loop:
    a. **Read the Plan:** Your first action is ALWAYS to call \`readFile\` on \`PROJECT_ARCHITECTURE.md\`.
    b. **Find the Next Task:** Parse the "Implementation Plan & Task Breakdown" table. Find the *first* task with a status of \`PENDING\`.
    c. **Execute the Task:** Use your tools to perform the action described in that task. This may involve reading other files and then calling \`updateFile\`.
    d. **Update the Plan:** After the task is successfully completed, your *very next action* MUST be to call \`updateFile\` on \`PROJECT_ARCHITECTURE.md\` to:
        i.  Change the status of the completed task to \`COMPLETED\`.
        ii. Add a new entry to the "Execution Log" table detailing what you did.
    e. **Repeat:** The loop continues until no \`PENDING\` tasks remain.

---

### General Directives & Best Practices

*   **Batch Your Changes:** The \`updateFile\` tool is powerful. If you need to make multiple changes to a single file, do it in one call by providing an array of change objects. This is much more efficient.
*   **Code Intelligence:** Use the \`get_code_symbols_outline\` tool to quickly understand the structure of a file before reading it fully. This helps you locate relevant code and line numbers faster.
*   **Be Incremental:** Break down large user requests into smaller, specific tasks within the PAD.
*   **Think Step-by-Step:** In your responses, briefly explain your reasoning or plan *before* you call the tools. This helps the user follow your logic.
*   **File-Based Operations Only:** You do not output code blocks in the chat. All file creation and modification MUST go through your tools (\`createFile\`, \`updateFile\`, etc.).
*   **Pathing:** All file paths are relative to the project root (e.g., \`script.js\`, \`css/main.css\`). Use \`/\` as the directory separator.
*   **Project Completion:** Only call the \`projectComplete\` tool when all tasks in the PAD are marked \`COMPLETED\` and the user's high-level request has been fully satisfied.`;

/**
 * The configuration object defining the function-calling tools for the Gemini API.
 * @type {Array<Object>}
 */
export const toolsConfig = [{
    functionDeclarations: [
        { name: 'createFile', description: 'Creates a new file with specified content.', parameters: { type: Type.OBJECT, properties: { path: { type: Type.STRING }, content: { type: Type.STRING, description: "The initial content of the file." } }, required: ['path', 'content'] } },
        {
            name: 'updateFile',
            description: 'Applies a set of targeted changes to an existing file by specifying line numbers. This is the primary method for modifying code.',
            parameters: {
                type: Type.OBJECT,
                properties: {
                    path: { type: Type.STRING },
                    explanation: { type: Type.STRING, description: "A brief, user-facing explanation of the overall change being made." },
                    changes: {
                        type: Type.ARRAY,
                        description: "An array of change objects to apply to the file.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                startLine: { type: Type.NUMBER, description: "The 1-indexed line number where the change begins." },
                                endLine: { type: Type.NUMBER, description: "The 1-indexed line number where the change ends (inclusive). To insert, use the same line number for start and end." },
                                newContent: { type: Type.STRING, description: "The new code that will replace the content from startLine to endLine." }
                            },
                            required: ['startLine', 'endLine', 'newContent']
                        }
                    }
                },
                required: ['path', 'explanation', 'changes']
            }
        },
        { name: 'deleteFile', description: 'Deletes a file or an entire folder at a given path.', parameters: { type: Type.OBJECT, properties: { path: { type: Type.STRING } }, required: ['path'] } },
        { name: 'renamePath', description: 'Renames a file or folder.', parameters: { type: Type.OBJECT, properties: { oldPath: { type: Type.STRING }, newPath: { type: Type.STRING } }, required: ['oldPath', 'newPath'] } },
        { name: 'readFile', description: 'Reads the entire content of a file. Use this to understand existing code and get line numbers before modifying it.', parameters: { type: Type.OBJECT, properties: { path: { type: Type.STRING } }, required: ['path'] } },
        { name: 'readFileLines', description: 'Reads a specific range of lines from a file for more focused context.', parameters: { type: Type.OBJECT, properties: { path: { type: Type.STRING }, startLine: { type: Type.NUMBER }, endLine: { type: Type.NUMBER } }, required: ['path', 'startLine', 'endLine'] } },
        { name: 'get_code_symbols_outline', description: 'Provides a structural outline of a file by listing its functions, classes, and other important symbols. Can also fetch the definition of a single symbol.', parameters: { type: Type.OBJECT, properties: { path: { type: Type.STRING }, symbolName: { type: Type.STRING, description: "Optional. If provided, returns the definition snippet for this specific symbol." } }, required: ['path'] } },
        { name: 'searchProject', description: 'Searches for a text pattern or regex across all files in the project.', parameters: { type: Type.OBJECT, properties: { query: { type: Type.STRING }, isRegex: { type: Type.BOOLEAN } }, required: ['query'] } },
        { name: 'fetchProjectRules', description: 'Fetches project-specific rules and guidelines. Call without a name to get a list of all rule names.', parameters: { type: Type.OBJECT, properties: { ruleName: { type: Type.STRING } }, required: [] } },
        { name: 'askUserForConfirmation', description: 'Asks the user a yes/no question to confirm a high-level plan or a destructive action before executing it. The user will respond in the next turn.', parameters: { type: Type.OBJECT, properties: { question: { type: 'string' } }, required: ['question'] } },
        { name: 'projectComplete', description: 'Call this when you believe the user\'s request is fully complete.', parameters: { type: Type.OBJECT, properties: { message: { type: 'string' } }, required: ['message'] } }
    ]
}];

/**
 * The key used in localStorage to remember the last opened project.
 * @type {string}
 */
export const LAST_SESSION_KEY = 'archieIDE_lastSession';

/**
 * The minimum interval in milliseconds between consecutive API calls to avoid rate limiting.
 * @type {number}
 */
export const MIN_API_CALL_INTERVAL_MS = 6500; // 10 RPM is 6s/req. Add buffer.