/**
 * @file js/vfs.js
 * @description Defines the Virtual File System (VFS) class for managing file state in memory.
 */

/**
 * A class that represents the project's file system in memory.
 * It stores files as a key-value pair, where the key is the full path
 * and the value is the file content. Folders are represented implicitly by
 * their path prefixes or explicitly as a path ending in '/' with a null value.
 */
export class VirtualFileSystem {
    /**
     * Initializes the VFS with an empty file object.
     */
    constructor() {
        /**
         * The core data store for files.
         * @type {Object.<string, string|null>}
         */
        this.files = {};
    }

    /**
     * Loads a set of base files into the VFS, replacing any existing content.
     * @param {Object.<string, string|null>} baseFiles - An object representing the file system state.
     */
    load(baseFiles) {
        this.files = { ...baseFiles };
    }

    /**
     * Applies a change to a single file.
     * If newContent is null, the file is deleted. Otherwise, it's created or updated.
     * @param {string} path - The full path of the file.
     * @param {string|null} newContent - The new content of the file, or null to delete.
     */
    applyChange(path, newContent) {
        if (newContent === null) {
            // Also remove any child files if deleting a directory
            if (path.endsWith('/')) {
                Object.keys(this.files).forEach(p => {
                    if (p.startsWith(path)) {
                        delete this.files[p];
                    }
                });
            }
            delete this.files[path];
        } else {
            this.files[path] = newContent;
        }
    }

    /**
     * Reads the content of a file from the VFS.
     * @param {string} path - The full path of the file to read.
     * @returns {string|undefined} The content of the file, or undefined if it doesn't exist.
     */
    read(path) {
        return this.files[path];
    }

    /**
     * Generates a nested object representing the directory tree structure.
     * This is used for rendering the file explorer.
     * @returns {Object} A hierarchical object representing the file tree.
     */
    getTree() {
        const tree = {};
        // Sort keys to ensure consistent order
        Object.keys(this.files).sort().forEach(path => {
            let currentLevel = tree;
            // Split path into parts, removing any empty strings from leading/trailing slashes
            const parts = path.split('/').filter(p => p);

            parts.forEach((part, i) => {
                const isFile = (i === parts.length - 1 && this.files[path] !== null);

                if (isFile) {
                    currentLevel[part] = 'file';
                } else {
                    // It's a directory
                    currentLevel[part] = currentLevel[part] || {};
                    currentLevel = currentLevel[part];
                }
            });
        });
        return tree;
    }

    /**
     * Generates a string representation of the file tree.
     * This is useful for providing context to the AI.
     * @returns {string} A formatted string of the file tree.
     */
    getTreeString() {
        let output = '';
        const generate = (level, indent) => {
            // Sort directories before files
            const sortedKeys = Object.keys(level).sort((a, b) => {
                const aIsFile = level[a] === 'file';
                const bIsFile = level[b] === 'file';
                if (aIsFile === bIsFile) return a.localeCompare(b);
                return aIsFile ? 1 : -1;
            });

            for (const name of sortedKeys) {
                const isFile = level[name] === 'file';
                output += `${' '.repeat(indent*2)}${isFile ? '📄' : '📁'} ${name}\n`;
                if (!isFile) {
                    generate(level[name], indent + 1);
                }
            }
        };
        generate(this.getTree(), 0);
        return output || '(No files in project)';
    }
}