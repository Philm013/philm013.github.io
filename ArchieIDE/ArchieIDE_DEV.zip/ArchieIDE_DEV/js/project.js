/**
 * @file js/project.js
 * @description Handles all project lifecycle management, including creation, loading,
 * saving, committing, versioning, and import/export functionality.
 */

import { DB } from './db.js';
import {
    App, setConversationHistory, setUncommittedChanges, conversationHistory, uncommittedChanges
} from './state.js';
import {
    renderAll, updateChangesUI, logToTerminal, renderPadView,
    renderRulesUI, renderTerminalFromHistory, showProjectManager,
    closeFile, renderGitHubView
} from './ui.js';
import { submitPrompt, reconstructAndCleanHistory } from './api.js';
import { SYSTEM_PROMPT, PAD_TEMPLATE, LAST_SESSION_KEY } from './constants.js';

/**
 * Saves the current project's metadata (history, rules) to IndexedDB.
 * This function should be called after any change to history or rules.
 * Note: File content is saved via the commit snapshot system, not here.
 * @returns {Promise<void>}
 */
export async function saveProjectState() {
    if (!App.currentProjectName) return;

    // Prune history before saving to reduce storage size.
    const prunedHistory = (history) => {
        if (!Array.isArray(history)) return [];
        const contextMarker = '== PROJECT CONTEXT ==';
        return history.map(entry => {
            const newEntry = JSON.parse(JSON.stringify(entry));
            if (newEntry.role === 'model' && newEntry.parts) {
                newEntry.parts.forEach(part => {
                    if (part.functionCall?.args.content) part.functionCall.args.content = '(Content pruned)';
                });
            }
            if (newEntry.role === 'user' && newEntry.parts?.[0]?.text) {
                const contextIndex = newEntry.parts[0].text.indexOf(contextMarker);
                if (contextIndex !== -1) newEntry.parts[0].text = newEntry.parts[0].text.substring(0, contextIndex).trim();
            }
            return newEntry;
        });
    };

    const projectData = {
        name: App.currentProjectName,
        lastModified: Date.now(),
        history: prunedHistory(conversationHistory),
        rules: App.rules,
        githubRepo: App.githubRepo,
        githubBranch: App.githubBranch,
    };
    await DB.saveProject(projectData);
}

/**
 * Loads a project from IndexedDB into the application state.
 * @param {string} projectName - The name of the project to load.
 * @returns {Promise<boolean>} True if loading was successful, false otherwise.
 */
export async function loadProject(projectName) {
    // Reset current state
    App.openFiles = new Set();
    App.activeFile = null;
    App.previewModeFiles = new Set();
    App.githubConnected = false;

    App.currentProjectName = projectName;
    const projects = await DB.getProjects();
    const projectData = projects.find(proj => proj.name === projectName);

    if (!projectData) {
        console.error("Project not found in DB:", projectName);
        return false;
    }

    // Load files from the latest commit
    const files = await DB.getLatestFileSnapshots(projectName);
    App.vfs.load(files);

    // Load metadata
    App.rules = projectData.rules || {};
    App.githubRepo = projectData.githubRepo || null;
    App.githubBranch = projectData.githubBranch || null;
    setConversationHistory(projectData.history || []);
    setUncommittedChanges({});

    // Update UI
    document.querySelector('#project-title-display').textContent = App.currentProjectName;
    renderAll();
    renderPadView();
    renderTerminalFromHistory();
    renderRulesUI();
    renderGitHubView();
    updateChangesUI();
    localStorage.setItem(LAST_SESSION_KEY, projectName);
    return true;
}

/**
 * Creates a new, empty project with a default PAD file and scaffolds it based on a user description.
 * @param {string} description - A user-provided description of the project to build.
 * @returns {Promise<void>}
 */
export async function startNewProject(description) {
    const projectName = prompt("Enter a name for your new project:", "My New App");
    if (!projectName) return;

    App.currentProjectName = projectName;
    App.vfs.load({});
    App.rules = {};
    App.githubRepo = null;
    App.githubBranch = null;
    App.githubConnected = false;
    setUncommittedChanges({});
    setConversationHistory([
        { role: 'user', parts: [{ text: SYSTEM_PROMPT }] },
        { role: 'model', parts: [{ text: "Okay, I am Archie. I'm ready to start." }] }
    ]);

    // Create and stage the initial Project Architecture Document
    const padContent = PAD_TEMPLATE.replace('[ProjectHandle]', projectName).replace('{timestamp}', new Date().toISOString());
    App.vfs.applyChange('PROJECT_ARCHITECTURE.md', padContent);

    // Save initial project structure
    await saveProjectState();
    localStorage.setItem(LAST_SESSION_KEY, projectName);

    document.querySelector('#project-title-display').textContent = App.currentProjectName;
    renderAll();
    renderPadView();
    renderTerminalFromHistory();
    renderRulesUI();
    renderGitHubView();
    updateChangesUI();

    document.querySelector('#project-start-modal').style.display = 'none';
    document.querySelector('#app-container').style.display = 'flex';

    logToTerminal(`Scaffolding new project: ${description}`, 'system');
    const initialPrompt = `The user wants to start a new project called "${projectName}". Here is their description: "${description}". Please analyze the default PROJECT_ARCHITECTURE.md file and then use your tools to create all the necessary files and folder structure outlined in it.`;

    await submitPrompt(initialPrompt);
}

/**
 * Creates a versioned commit of all current (and staged) changes.
 * @returns {Promise<void>}
 */
export async function commitChanges() {
    const message = document.querySelector('#commit-message').value.trim();
    if (!message) {
        alert("Please enter a commit message.");
        return;
    }

    const commitId = `commit_${Date.now()}`;
    const commitData = {
        id: commitId,
        projectName: App.currentProjectName,
        message: message,
        timestamp: Date.now(),
        changes: Object.keys(uncommittedChanges)
    };

    // Create a snapshot of the entire VFS at this point in time
    const snapshots = Object.entries(App.vfs.files).map(([path, content]) => ({
        commitId: commitId,
        path: path,
        content: content
    }));

    await DB.saveFileSnapshots(snapshots);
    await DB.saveCommit(commitData);
    await saveProjectState(); // Save updated history

    setUncommittedChanges({});
    document.querySelector('#commit-message').value = '';
    updateChangesUI();
    logToTerminal(`Changes committed: "${message}"`, 'system');
}

/**
 * Discards all uncommitted changes and reverts the VFS to the last committed state.
 * @returns {Promise<void>}
 */
export async function restoreToLastCommit() {
    if (!confirm("Are you sure you want to discard all uncommitted changes? This cannot be undone.")) {
        return;
    }
    const files = await DB.getLatestFileSnapshots(App.currentProjectName);
    App.vfs.load(files);
    setUncommittedChanges({});

    // Close any files that no longer exist
    App.openFiles.forEach(path => {
        if (!App.vfs.files[path]) {
            closeFile(path);
        }
    });

    renderAll();
    renderPadView();
    updateChangesUI();
    logToTerminal('Uncommitted changes have been discarded and restored to the last commit.', 'system');
}

/**
 * Handles the import of multiple files or a directory into the current project.
 * @param {Event} event - The file input change event.
 */
export async function handleProjectImport(event) {
    const files = event.target.files;
    if (!files.length) return;

    const defaultName = files.length > 0 && files[0].webkitRelativePath ? files[0].webkitRelativePath.split('/')[0] : 'imported-project';
    const projectName = prompt("Enter a name for your new imported project:", defaultName);
    if (!projectName) {
        event.target.value = ''; // Reset file input
        return;
    }

    // Set up a new project context
    App.currentProjectName = projectName;
    App.vfs.load({});
    App.rules = {};
    App.githubRepo = null;
    App.githubBranch = null;
    App.githubConnected = false;
    setUncommittedChanges({});
    setConversationHistory([
        { role: 'user', parts: [{ text: SYSTEM_PROMPT }] },
        { role: 'model', parts: [{ text: "Okay, I am Archie. I'm ready to start." }] }
    ]);
    await saveProjectState();
    localStorage.setItem(LAST_SESSION_KEY, projectName);
    document.querySelector('#project-title-display').textContent = App.currentProjectName;

    // Read and load all files into VFS
    const readFileAsPromise = (file) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve({ path: file.webkitRelativePath || file.name, content: e.target.result });
        reader.onerror = reject;
        const isBinary = ['image/', 'audio/', 'video/'].some(type => file.type.startsWith(type));
        if (isBinary) reader.readAsDataURL(file);
        else reader.readAsText(file);
    });

    const fileResults = await Promise.all(Array.from(files).map(readFileAsPromise));
    fileResults.forEach(result => App.vfs.applyChange(result.path, result.content));
    
    // Create an initial commit for the import
    setUncommittedChanges(Object.fromEntries(fileResults.map(r => [r.path, { oldContent: '', newContent: r.content }])));
    document.querySelector('#commit-message').value = "Initial project import";
    await commitChanges();

    document.querySelector('#project-start-modal').style.display = 'none';
    document.querySelector('#app-container').style.display = 'flex';
    renderAll();
    renderPadView();
    renderRulesUI();
    renderGitHubView();
    updateChangesUI();
    logToTerminal(`Project "${projectName}" created from ${files.length} imported files.`, 'system');
    event.target.value = ''; // Reset file input
}

/**
 * Downloads the current state of the VFS as a ZIP file.
 * @returns {Promise<void>}
 */
export async function downloadProjectAsZip() {
    logToTerminal("Preparing project for download...", "system");
    const zip = new JSZip();
    Object.keys(App.vfs.files).forEach(path => {
        const content = App.vfs.files[path];
        if (content === null) {
            // It's an empty folder, ensure it's created
            if (!Object.keys(App.vfs.files).some(p => p.startsWith(path) && p !== path)) {
                zip.folder(path.slice(0, -1));
            }
        } else {
            // It's a file
            if (content.startsWith('data:')) {
                const [_, base64Data] = content.split(',', 2);
                zip.file(path, base64Data, { base64: true });
            } else {
                zip.file(path, content);
            }
        }
    });
    const zipBlob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${App.currentProjectName.replace(/\s+/g, '-') || 'archie-project'}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    logToTerminal("Project ZIP file generated.", "system");
}

/**
 * Checks if a file is likely binary based on its MIME type or extension.
 * @param {File} file - The file object to check.
 * @returns {boolean} True if the file is likely binary.
 */
function isBinary(file) {
    const binaryTypes = ['image/', 'audio/', 'video/', 'application/octet-stream', 'application/zip', 'application/pdf'];
    const binaryExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.mp3', '.mp4', '.woff', '.woff2', '.ttf', '.eot'];
    return binaryTypes.some(type => file.type.startsWith(type)) || binaryExtensions.some(ext => file.name.endsWith(ext));
}

/**
 * Reads a file object and returns its path and content.
 * Handles both text and binary (as Data URL) files.
 * @param {File} file - The file to read.
 * @returns {Promise<{path: string, content: string}>} A promise resolving to the file's data.
 */
function readFileAsPromise(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve({ path: file.webkitRelativePath || file.name, content: e.target.result });
        reader.onerror = reject;
        if (isBinary(file)) {
            reader.readAsDataURL(file);
        } else {
            reader.readAsText(file);
        }
    });
}

/**
 * One-time migration function to move project data from localStorage to IndexedDB.
 * @returns {Promise<void>}
 */
export async function migrateFromLocalStorage() {
    const oldProjectListKey = 'archieIDE_projectList';
    const oldProjectListJSON = localStorage.getItem(oldProjectListKey);
    if (!oldProjectListJSON) return;

    logToTerminal("Old project data found. Starting migration to new storage system...", 'system');
    let migrationCount = 0;
    try {
        const oldProjectNames = JSON.parse(oldProjectListJSON);
        for (const name of oldProjectNames) {
            const oldProjectKey = `archieIDE_project_${name}`;
            const oldProjectJSON = localStorage.getItem(oldProjectKey);
            if (!oldProjectJSON) continue;

            const oldData = JSON.parse(oldProjectJSON);
            App.currentProjectName = oldData.name || name;
            App.vfs.load(oldData.files || {});
            App.rules = oldData.rules || {};
            setConversationHistory(oldData.history || []);
            setUncommittedChanges({});

            // Create a migrated commit
            document.querySelector('#commit-message').value = "Initial migration from localStorage";
            await commitChanges();
            migrationCount++;
            logToTerminal(`Successfully migrated project: ${name}`, 'system');
        }

        oldProjectNames.forEach(name => localStorage.removeItem(`archieIDE_project_${name}`));
        localStorage.removeItem(oldProjectListKey);

        if (migrationCount > 0) {
            alert(`Successfully migrated ${migrationCount} project(s) to the new, more robust storage system! Your projects are safe.`);
        }
    } catch (error) {
        console.error("Error during data migration:", error);
        alert("An error occurred while trying to migrate your old projects. Please check the console for details.");
    } finally {
        // Reset state after migration attempt
        App.currentProjectName = null;
        App.vfs.load({});
        setConversationHistory([]);
    }
}