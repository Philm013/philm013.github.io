/**
 * @file js/state.js
 * @description Centralized state management for the application.
 */

import { VirtualFileSystem } from './vfs.js';

// --- Private State Variables ---

// App state that is NOT persisted
let _stagedImage = null;
let _isGenerating = false;
let _isAutoMode = false;
let _lastApiCallTimestamp = 0;
let _pendingGuidance = null;

// App state that IS persisted (as part of project data)
let _conversationHistory = [];
let _uncommittedChanges = {}; // { path: { oldContent, newContent } }


// --- Publicly Accessible, Mutable App Object ---

/**
 * The main application state object.
 * @type {object}
 */
export const App = {
    // Core Components (initialized in main.js)
    vfs: new VirtualFileSystem(),
    ai: null,
    markdownConverter: null,

    // Project State
    currentProjectName: null,
    openFiles: new Set(),
    activeFile: null,
    previewModeFiles: new Set(),
    rules: {}, // { ruleName: ruleContent }

    // UI State
    mobileView: 'editor',
    selectedModel: 'gemini-1.5-flash-latest',

    // GitHub Integration State
    githubToken: null,
    githubRepo: null,
    githubBranch: null,
    githubConnected: false,

    // --- Getters for private state ---
    get stagedImage() { return _stagedImage; },
    get isGenerating() { return _isGenerating; },
    get isAutoMode() { return _isAutoMode; },
    get lastApiCallTimestamp() { return _lastApiCallTimestamp; },
    get pendingGuidance() { return _pendingGuidance; },
    get conversationHistory() { return _conversationHistory; },
    get uncommittedChanges() { return _uncommittedChanges; },

    // --- Setters for private state (to control mutation) ---
    set isGenerating(value) { _isGenerating = value; },
    set isAutoMode(value) { _isAutoMode = value; },

    // --- Utility functions ---
    isMobile: () => window.innerWidth <= 768,
};


// --- Helper Functions for State Management ---

/**
 * A convenience function for document.querySelector.
 * @param {string} selector - The CSS selector.
 * @returns {HTMLElement|null} The found element.
 */
export const $ = (selector) => document.querySelector(selector);

/**
 * Sets the AI instance.
 * @param {GoogleGenAI} newAi - The new AI instance.
 */
export function setAi(newAi) {
    App.ai = newAi;
}

/**
 * Sets the markdown converter instance.
 * @param {Showdown.Converter} newConverter - The new converter instance.
 */
export function setMarkdownConverter(newConverter) {
    App.markdownConverter = newConverter;
}

/**
 * Sets the staged image object.
 * @param {object|null} image - The image object { base64, mimeType } or null.
 */
export function setStagedImage(image) {
    _stagedImage = image;
}

/**
 * Sets the entire conversation history array.
 * @param {Array<object>} history - The new history array.
 */
export function setConversationHistory(history) {
    _conversationHistory = history || [];
}

/**
 * Pushes one or more entries to the conversation history.
 * @param {...object} entries - The entries to add.
 */
export function pushToConversationHistory(...entries) {
    _conversationHistory.push(...entries);
}

/**
 * Sets the entire uncommitted changes object.
 * @param {object} changes - The new changes object.
 */
export function setUncommittedChanges(changes) {
    _uncommittedChanges = changes || {};
}

/**
 * Sets the timestamp of the last API call.
 * @param {number} timestamp - The new timestamp.
 */
export function setLastApiCallTimestamp(timestamp) {
    _lastApiCallTimestamp = timestamp;
}

/**
 * Sets pending guidance for auto-mode.
 * @param {string|null} guidance - The guidance text.
 */
export function setPendingGuidance(guidance) {
    _pendingGuidance = guidance;
}


// --- Expose read-only versions of state for safe access ---
export const stagedImage = () => _stagedImage;
export const conversationHistory = () => _conversationHistory;
export const uncommittedChanges = () => _uncommittedChanges;