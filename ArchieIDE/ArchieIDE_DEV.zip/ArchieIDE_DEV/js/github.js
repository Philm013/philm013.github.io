/**
 * @file js/github.js
 * @description Manages all communication with the GitHub API for pulling and pushing project files.
 */

import { App, uncommittedChanges, setUncommittedChanges } from './state.js';
import { logToGitHub, renderGitHubView, renderAll, updateChangesUI, logToTerminal } from './ui.js';
import { commitChanges } from './project.js';

const GITHUB_API_URL = 'https://api.github.com';
const GITHUB_TOKEN_KEY = 'archie_github_pat';

/**
 * Creates the authorization headers for GitHub API requests.
 * @returns {Headers} A Headers object with the authorization token.
 */
function _getAuthHeaders() {
    const headers = new Headers({
        'Accept': 'application/vnd.github.v3+json',
        'X-GitHub-Api-Version': '2022-11-28'
    });
    if (App.githubToken) {
        headers.append('Authorization', `Bearer ${App.githubToken}`);
    }
    return headers;
}

/**
 * A wrapper for fetch to handle GitHub API requests and errors.
 * @param {string} url - The URL to fetch.
 * @param {object} options - The options for the fetch request.
 * @returns {Promise<any>} The JSON response from the API.
 */
async function _fetchGitHubAPI(url, options = {}) {
    const response = await fetch(`${GITHUB_API_URL}${url}`, {
        ...options,
        headers: _getAuthHeaders()
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`GitHub API Error: ${errorData.message || response.statusText}`);
    }
    // Handle responses with no content (like 204)
    if (response.status === 204) {
        return null;
    }
    return response.json();
}

/**
 * Saves the GitHub PAT to localStorage and application state.
 */
export function saveToken() {
    const tokenInput = document.getElementById('github-pat-input');
    const token = tokenInput.value.trim();
    if (token) {
        localStorage.setItem(GITHUB_TOKEN_KEY, token);
        App.githubToken = token;
        logToGitHub('GitHub token saved to browser storage.', 'success');
        tokenInput.value = '';
    } else {
        logToGitHub('Please enter a token.', 'error');
    }
}

/**
 * Loads the GitHub PAT from localStorage into application state.
 */
export function loadToken() {
    const token = localStorage.getItem(GITHUB_TOKEN_KEY);
    if (token) {
        App.githubToken = token;
        logToGitHub('GitHub token loaded from browser storage.');
        return true;
    }
    return false;
}

/**
 * Connects to a GitHub repository, verifying its existence and fetching the default branch.
 */
export async function connect() {
    const repoInput = document.getElementById('github-repo-input');
    const repo = repoInput.value.trim();
    if (!repo.match(/^[a-zA-Z0-9-]+\/[a-zA-Z0-9-._]+$/)) {
        logToGitHub("Invalid repository format. Please use 'owner/repo'.", 'error');
        return;
    }
    if (!App.githubToken) {
        logToGitHub("Please save a GitHub PAT first.", 'error');
        return;
    }

    try {
        logToGitHub(`Connecting to ${repo}...`);
        const repoData = await _fetchGitHubAPI(`/repos/${repo}`);
        App.githubRepo = repo;
        App.githubBranch = repoData.default_branch;
        App.githubConnected = true;
        logToGitHub(`Connected successfully to ${repo} on branch '${App.githubBranch}'.`, 'success');
        renderGitHubView();
    } catch (error) {
        logToGitHub(`Failed to connect: ${error.message}`, 'error');
        App.githubConnected = false;
        renderGitHubView();
    }
}

/**
 * Disconnects from the current GitHub repository.
 */
export function disconnect() {
    App.githubRepo = null;
    App.githubBranch = null;
    App.githubConnected = false;
    logToGitHub('Disconnected from repository.');
    renderGitHubView();
}

/**
 * Pulls all files from the connected repository, overwriting the local VFS.
 */
export async function pull() {
    if (!App.githubConnected) {
        logToGitHub('Not connected to any repository.', 'error');
        return;
    }
    if (!confirm('This will overwrite all local files and uncommitted changes. Are you sure?')) {
        return;
    }

    try {
        logToGitHub(`Starting pull from ${App.githubRepo}...`);
        
        // 1. Get the latest commit SHA for the branch
        const refData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/ref/heads/${App.githubBranch}`);
        const commitSha = refData.object.sha;
        logToGitHub(`Latest commit SHA: ${commitSha.substring(0, 7)}`);

        // 2. Get the tree for that commit, recursively
        const treeData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/trees/${commitSha}?recursive=1`);
        
        // 3. Filter for file blobs and fetch them
        const fileBlobs = treeData.tree.filter(item => item.type === 'blob');
        logToGitHub(`Found ${fileBlobs.length} files to download.`);

        // 4. Reset local state
        App.vfs.load({});
        setUncommittedChanges({});

        // 5. Fetch all blobs and populate VFS
        const blobPromises = fileBlobs.map(async (blob) => {
            const blobData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/blobs/${blob.sha}`);
            let content;
            if (blobData.encoding === 'base64') {
                // Check if it's a binary file by some heuristic (e.g. common extensions)
                const isBinary = /\.(png|jpg|jpeg|gif|webp|woff|woff2|eot|ttf|zip)$/i.test(blob.path);
                 if(isBinary) {
                     content = `data:application/octet-stream;base64,${blobData.content}`;
                 } else {
                     content = atob(blobData.content);
                 }
            } else {
                content = blobData.content;
            }
            App.vfs.applyChange(blob.path, content);
        });
        
        await Promise.all(blobPromises);
        
        // 6. Create a local commit to represent the pull
        document.querySelector('#commit-message').value = `Pulled from ${App.githubRepo}#${commitSha.substring(0,7)}`;
        Object.keys(App.vfs.files).forEach(path => {
            uncommittedChanges[path] = { oldContent: null, newContent: App.vfs.files[path] };
        });
        await commitChanges();

        logToGitHub('Pull complete. Local project synchronized with repository.', 'success');
        renderAll();
        updateChangesUI();
    } catch (error) {
        logToGitHub(`Pull failed: ${error.message}`, 'error');
    }
}


/**
 * Pushes the uncommitted changes in the IDE to the connected GitHub repository.
 * @param {string} commitMessage - The message for the GitHub commit.
 */
export async function push(commitMessage) {
    if (!App.githubConnected) {
        logToGitHub('Not connected to any repository.', 'error');
        return;
    }
    const changesToPush = Object.keys(uncommittedChanges);
    if (changesToPush.length === 0) {
        logToGitHub('No uncommitted changes to push.', 'info');
        return;
    }

    try {
        logToGitHub(`Starting push of ${changesToPush.length} changes to ${App.githubRepo}...`);

        // 1. Get the latest commit SHA (parent) and its tree SHA
        const refData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/ref/heads/${App.githubBranch}`);
        const parentCommitSha = refData.object.sha;
        const commitData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/commits/${parentCommitSha}`);
        const baseTreeSha = commitData.tree.sha;
        logToGitHub(`Parent commit: ${parentCommitSha.substring(0, 7)}`);

        // 2. Create blobs for all changed files
        const blobCreationPromises = [];
        for (const path of changesToPush) {
            const change = uncommittedChanges[path];
            // Skip deletions, they are handled by setting sha to null in the tree
            if (change.newContent !== null) {
                const promise = _fetchGitHubAPI(`/repos/${App.githubRepo}/git/blobs`, {
                    method: 'POST',
                    body: JSON.stringify({
                        content: change.newContent.startsWith('data:') ? change.newContent.split(',')[1] : change.newContent,
                        encoding: change.newContent.startsWith('data:') ? 'base64' : 'utf-8'
                    })
                }).then(blob => ({ path, sha: blob.sha }));
                blobCreationPromises.push(promise);
            }
        }
        const createdBlobs = await Promise.all(blobCreationPromises);
        logToGitHub(`Created ${createdBlobs.length} new blobs.`);

        // 3. Create the new tree
        const tree = changesToPush.map(path => {
            const change = uncommittedChanges[path];
            if (change.newContent === null) {
                // Deletion
                return { path, mode: '100644', type: 'blob', sha: null };
            } else {
                // Creation or modification
                const blob = createdBlobs.find(b => b.path === path);
                return { path, mode: '100644', type: 'blob', sha: blob.sha };
            }
        });

        const newTreeData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/trees`, {
            method: 'POST',
            body: JSON.stringify({
                base_tree: baseTreeSha,
                tree: tree
            })
        });
        logToGitHub(`Created new tree: ${newTreeData.sha.substring(0, 7)}`);
        
        // 4. Create the new commit
        const newCommitData = await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/commits`, {
            method: 'POST',
            body: JSON.stringify({
                message: commitMessage,
                tree: newTreeData.sha,
                parents: [parentCommitSha]
            })
        });
        logToGitHub(`Created new commit: ${newCommitData.sha.substring(0, 7)}`);

        // 5. Update the branch reference
        await _fetchGitHubAPI(`/repos/${App.githubRepo}/git/refs/heads/${App.githubBranch}`, {
            method: 'PATCH',
            body: JSON.stringify({
                sha: newCommitData.sha
            })
        });

        logToGitHub('Push successful!', 'success');
        logToTerminal(`Pushed changes to GitHub: "${commitMessage}"`);

        // 6. Clear local uncommitted changes
        setUncommittedChanges({});
        updateChangesUI();
    } catch (error) {
        logToGitHub(`Push failed: ${error.message}`, 'error');
    }
}